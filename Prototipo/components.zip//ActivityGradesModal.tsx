import { useState } from 'react';
import { X, Save, Target, Users, Calculator } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';

const mockStudents = [
  { id: 1, name: 'Ana María López', grade: null },
  { id: 2, name: 'Carlos Roberto Mendez', grade: null },
  { id: 3, name: 'María José Hernández', grade: null },
  { id: 4, name: 'Diego Alexander Ruiz', grade: null },
  { id: 5, name: 'Sofía Isabella García', grade: null },
  { id: 6, name: 'Luis Fernando Morales', grade: null },
  { id: 7, name: 'Carmen Elena Rodríguez', grade: null },
  { id: 8, name: 'José Antonio Paz', grade: null },
  { id: 9, name: 'Valeria Beatriz Torres', grade: null },
  { id: 10, name: 'Gabriel Eduardo Méndez', grade: null }
];

export function ActivityGradesModal({ activity, onClose, onSuccess }) {
  const [students, setStudents] = useState(
    activity.studentsGraded > 0 
      ? mockStudents.map((student, index) => ({
          ...student,
          grade: index < activity.studentsGraded ? Math.floor(Math.random() * 40) + 60 : null
        }))
      : mockStudents
  );
  const [isSaving, setIsSaving] = useState(false);

  const updateGrade = (studentId, grade) => {
    const numericGrade = parseFloat(grade);
    if (isNaN(numericGrade) || numericGrade < 0 || numericGrade > activity.points) return;

    setStudents(prev => prev.map(student => 
      student.id === studentId 
        ? { ...student, grade: numericGrade }
        : student
    ));
  };

  const getGradeColor = (grade, maxPoints) => {
    if (grade === null || grade === undefined) return 'border-gray-300';
    const percentage = (grade / maxPoints) * 100;
    if (percentage >= 70) return 'border-green-500 bg-green-50 text-green-800';
    return 'border-red-500 bg-red-50 text-red-800';
  };

  const getGradePercentage = (grade, maxPoints) => {
    if (grade === null || grade === undefined) return null;
    return ((grade / maxPoints) * 100).toFixed(1);
  };

  const studentsWithGrades = students.filter(s => s.grade !== null && s.grade !== undefined);
  const averageGrade = studentsWithGrades.length > 0 
    ? studentsWithGrades.reduce((sum, s) => sum + s.grade, 0) / studentsWithGrades.length
    : 0;
  const averagePercentage = (averageGrade / activity.points) * 100;

  const handleSave = async () => {
    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const gradedCount = studentsWithGrades.length;
    const updatedActivity = {
      studentsGraded: gradedCount,
      averageGrade: gradedCount > 0 ? averageGrade : null,
      status: gradedCount === students.length ? 'completed' : gradedCount > 0 ? 'grading' : 'pending'
    };
    
    onSuccess(updatedActivity);
    setIsSaving(false);
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-4xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center mr-3">
              <Target className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                Calificar: {activity.name}
              </h2>
              <p className="text-sm text-gray-600">
                {activity.subject} • {activity.grade} - Sección {activity.section} • {activity.points} puntos
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Stats */}
        <div className="p-6 bg-gray-50 border-b border-gray-100">
          <div className="grid grid-cols-4 gap-4">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Users className="w-5 h-5 text-gray-600 mr-1" />
              </div>
              <p className="text-2xl font-bold text-gray-900">{students.length}</p>
              <p className="text-sm text-gray-600">Total</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Calculator className="w-5 h-5 text-blue-600 mr-1" />
              </div>
              <p className="text-2xl font-bold text-blue-800">{studentsWithGrades.length}</p>
              <p className="text-sm text-blue-600">Calificados</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Target className="w-5 h-5 text-green-600 mr-1" />
              </div>
              <p className="text-2xl font-bold text-green-800">
                {studentsWithGrades.length > 0 ? averageGrade.toFixed(1) : '--'}
              </p>
              <p className="text-sm text-green-600">Promedio</p>
            </div>
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <span className="text-purple-600">%</span>
              </div>
              <p className="text-2xl font-bold text-purple-800">
                {studentsWithGrades.length > 0 ? averagePercentage.toFixed(1) : '--'}%
              </p>
              <p className="text-sm text-purple-600">Porcentaje</p>
            </div>
          </div>
        </div>

        {/* Students List */}
        <div className="p-6 max-h-[50vh] overflow-y-auto">
          <div className="space-y-3">
            {students.map((student) => (
              <div key={student.id} className="flex items-center justify-between py-3 px-4 bg-gray-50 rounded-xl">
                <div className="flex-1">
                  <p className="font-medium text-gray-900">{student.name}</p>
                </div>
                
                <div className="flex items-center space-x-4">
                  {/* Grade Input */}
                  <div className="flex items-center space-x-2">
                    <Input
                      type="number"
                      min="0"
                      max={activity.points}
                      placeholder={`0-${activity.points}`}
                      value={student.grade || ''}
                      onChange={(e) => updateGrade(student.id, e.target.value)}
                      className={`w-20 h-10 text-center rounded-lg ${getGradeColor(student.grade, activity.points)}`}
                    />
                    <span className="text-sm text-gray-500">/ {activity.points}</span>
                  </div>
                  
                  {/* Percentage */}
                  {student.grade !== null && student.grade !== undefined && (
                    <div className="text-right min-w-[60px]">
                      <Badge 
                        className={`text-xs ${
                          getGradePercentage(student.grade, activity.points) >= 70 
                            ? 'bg-green-500 hover:bg-green-600' 
                            : 'bg-red-500 hover:bg-red-600'
                        }`}
                      >
                        {getGradePercentage(student.grade, activity.points)}%
                      </Badge>
                    </div>
                  )}
                </div>
              </div>
            ))}
          </div>

          {/* Summary */}
          <div className="mt-6 pt-4 border-t border-gray-200">
            <div className="grid grid-cols-3 gap-4 text-sm">
              <div className="text-center">
                <p className="text-gray-600">Aprobados</p>
                <p className="font-semibold text-green-600">
                  {studentsWithGrades.filter(s => (s.grade / activity.points) * 100 >= 70).length}
                </p>
              </div>
              <div className="text-center">
                <p className="text-gray-600">Reprobados</p>
                <p className="font-semibold text-red-600">
                  {studentsWithGrades.filter(s => (s.grade / activity.points) * 100 < 70).length}
                </p>
              </div>
              <div className="text-center">
                <p className="text-gray-600">Pendientes</p>
                <p className="font-semibold text-gray-600">
                  {students.length - studentsWithGrades.length}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Actions */}
        <div className="flex justify-between p-6 border-t border-gray-100">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            className="rounded-xl"
          >
            Cerrar
          </Button>

          <Button
            onClick={handleSave}
            disabled={isSaving}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            <Save className="w-4 h-4 mr-2" />
            {isSaving ? 'Guardando...' : 'Guardar Calificaciones'}
          </Button>
        </div>
      </div>
    </div>
  );
}