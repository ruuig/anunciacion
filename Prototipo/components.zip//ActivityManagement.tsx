import { useState } from 'react';
import { 
  Plus, 
  Edit, 
  Trash2, 
  Calendar, 
  BookOpen, 
  Users,
  Target,
  Trophy,
  ClipboardCheck
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { CreateActivityModal } from './CreateActivityModal';
import { ActivityGradesModal } from './ActivityGradesModal';

const mockActivities = [
  {
    id: 1,
    name: 'Examen Parcial - Fracciones',
    subject: 'Matemáticas',
    grade: '3ro Primaria',
    section: 'A',
    period: 'Primer Bimestre',
    type: 'Examen',
    points: 25,
    date: '2024-02-15',
    status: 'completed',
    studentsGraded: 24,
    totalStudents: 28,
    averageGrade: 78.5
  },
  {
    id: 2,
    name: 'Tarea - Ejercicios de suma y resta',
    subject: 'Matemáticas',
    grade: '3ro Primaria',
    section: 'A',
    period: 'Primer Bimestre',
    type: 'Tarea',
    points: 10,
    date: '2024-02-10',
    status: 'completed',
    studentsGraded: 28,
    totalStudents: 28,
    averageGrade: 85.2
  },
  {
    id: 3,
    name: 'Proyecto - Sistema Solar',
    subject: 'Ciencias Naturales',
    grade: '4to Primaria',
    section: 'B',
    period: 'Primer Bimestre',
    type: 'Proyecto',
    points: 20,
    date: '2024-02-20',
    status: 'pending',
    studentsGraded: 0,
    totalStudents: 25,
    averageGrade: null
  }
];

const activityTypes = ['Examen', 'Tarea', 'Proyecto', 'Laboratorio', 'Presentación', 'Quiz'];
const periods = ['Primer Bimestre', 'Segundo Bimestre', 'Tercer Bimestre', 'Cuarto Bimestre'];

export function ActivityManagement({ user, availableGrades }) {
  const [activities, setActivities] = useState(mockActivities);
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [selectedPeriod, setSelectedPeriod] = useState('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingActivity, setEditingActivity] = useState(null);
  const [gradingActivity, setGradingActivity] = useState(null);

  const filteredActivities = activities.filter(activity => {
    const matchesGrade = selectedGrade === 'all' || activity.grade === selectedGrade;
    const matchesPeriod = selectedPeriod === 'all' || activity.period === selectedPeriod;
    return matchesGrade && matchesPeriod;
  });

  const getStatusColor = (status) => {
    switch (status) {
      case 'completed':
        return 'bg-green-500 hover:bg-green-600';
      case 'pending':
        return 'bg-orange-500 hover:bg-orange-600';
      case 'grading':
        return 'bg-blue-500 hover:bg-blue-600';
      default:
        return 'bg-gray-500 hover:bg-gray-600';
    }
  };

  const getStatusText = (status) => {
    switch (status) {
      case 'completed':
        return 'Completada';
      case 'pending':
        return 'Pendiente';
      case 'grading':
        return 'Calificando';
      default:
        return 'Sin estado';
    }
  };

  const getTypeIcon = (type) => {
    switch (type) {
      case 'Examen':
        return <ClipboardCheck className="w-4 h-4" />;
      case 'Tarea':
        return <BookOpen className="w-4 h-4" />;
      case 'Proyecto':
        return <Target className="w-4 h-4" />;
      default:
        return <BookOpen className="w-4 h-4" />;
    }
  };

  const handleCreateActivity = (activityData) => {
    const newActivity = {
      ...activityData,
      id: activities.length + 1,
      status: 'pending',
      studentsGraded: 0,
      totalStudents: 28, // Mock data
      averageGrade: null
    };
    setActivities([...activities, newActivity]);
  };

  const handleDeleteActivity = (activityId) => {
    if (confirm('¿Estás seguro de que quieres eliminar esta actividad? Esta acción no se puede deshacer.')) {
      setActivities(activities.filter(a => a.id !== activityId));
    }
  };

  const completedActivities = filteredActivities.filter(a => a.status === 'completed').length;
  const pendingActivities = filteredActivities.filter(a => a.status === 'pending').length;
  const totalPoints = filteredActivities.reduce((sum, a) => sum + a.points, 0);

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center mr-4">
              <ClipboardCheck className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">Gestión de Actividades</h2>
              <p className="text-gray-600">Planifica y califica actividades académicas</p>
            </div>
          </div>
          <Button 
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nueva Actividad
          </Button>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-green-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-green-800">{completedActivities}</p>
            <p className="text-sm text-green-600">Completadas</p>
          </div>
          <div className="bg-orange-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-orange-800">{pendingActivities}</p>
            <p className="text-sm text-orange-600">Pendientes</p>
          </div>
          <div className="bg-blue-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-blue-800">{totalPoints}</p>
            <p className="text-sm text-blue-600">Puntos Total</p>
          </div>
        </div>
      </div>

      {/* Filters */}
      <Card className="shadow-sm border-0 rounded-2xl">
        <CardContent className="p-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Filtrar por Grado
              </label>
              <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Todos los grados" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los grados</SelectItem>
                  {availableGrades.map((grade) => (
                    <SelectItem key={grade} value={grade}>
                      {grade}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Filtrar por Periodo
              </label>
              <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Todos los periodos" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los periodos</SelectItem>
                  {periods.map((period) => (
                    <SelectItem key={period} value={period}>
                      {period}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Activities List */}
      <div className="space-y-3">
        {filteredActivities.map((activity) => (
          <Card key={activity.id} className="shadow-sm border-0 rounded-2xl">
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-start">
                  <div className="w-12 h-12 bg-blue-100 rounded-xl flex items-center justify-center mr-4">
                    {getTypeIcon(activity.type)}
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center mb-2">
                      <h3 className="font-semibold text-gray-900 mr-3">{activity.name}</h3>
                      <Badge className={`text-xs ${getStatusColor(activity.status)}`}>
                        {getStatusText(activity.status)}
                      </Badge>
                    </div>
                    
                    <div className="grid grid-cols-2 gap-4 text-sm text-gray-600">
                      <div className="space-y-1">
                        <div className="flex items-center">
                          <BookOpen className="w-4 h-4 mr-2" />
                          {activity.subject}
                        </div>
                        <div className="flex items-center">
                          <Users className="w-4 h-4 mr-2" />
                          {activity.grade} - Sección {activity.section}
                        </div>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center">
                          <Calendar className="w-4 h-4 mr-2" />
                          {activity.date}
                        </div>
                        <div className="flex items-center">
                          <Target className="w-4 h-4 mr-2" />
                          {activity.points} puntos
                        </div>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col space-y-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setEditingActivity(activity)}
                    className="rounded-lg"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => handleDeleteActivity(activity.id)}
                    className="rounded-lg"
                  >
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </div>
              </div>

              {/* Progress and Actions */}
              <div className="pt-4 border-t border-gray-100">
                <div className="flex items-center justify-between">
                  <div className="flex-1">
                    <div className="flex items-center justify-between text-sm mb-2">
                      <span className="text-gray-600">
                        Progreso: {activity.studentsGraded}/{activity.totalStudents} estudiantes
                      </span>
                      {activity.averageGrade && (
                        <span className="font-medium">
                          Promedio: {activity.averageGrade.toFixed(1)}
                        </span>
                      )}
                    </div>
                    <div className="w-full bg-gray-200 rounded-full h-2">
                      <div 
                        className={`h-2 rounded-full ${
                          activity.status === 'completed' ? 'bg-green-500' : 'bg-blue-500'
                        }`}
                        style={{ 
                          width: `${(activity.studentsGraded / activity.totalStudents) * 100}%` 
                        }}
                      ></div>
                    </div>
                  </div>
                  
                  <div className="ml-4">
                    <Button
                      onClick={() => setGradingActivity(activity)}
                      className="bg-blue-500 hover:bg-blue-600 rounded-xl"
                    >
                      {activity.status === 'completed' ? 'Ver Notas' : 'Calificar'}
                    </Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredActivities.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <ClipboardCheck className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No hay actividades
          </h3>
          <p className="text-gray-600 mb-4">
            Crea tu primera actividad para comenzar a planificar evaluaciones
          </p>
          <Button 
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            <Plus className="w-4 h-4 mr-2" />
            Crear Primera Actividad
          </Button>
        </div>
      )}

      {/* Create Activity Modal */}
      {showCreateModal && (
        <CreateActivityModal
          availableGrades={availableGrades}
          onClose={() => setShowCreateModal(false)}
          onSuccess={handleCreateActivity}
        />
      )}

      {/* Edit Activity Modal */}
      {editingActivity && (
        <CreateActivityModal
          activity={editingActivity}
          availableGrades={availableGrades}
          onClose={() => setEditingActivity(null)}
          onSuccess={(updatedActivity) => {
            setActivities(activities.map(a => 
              a.id === editingActivity.id ? { ...a, ...updatedActivity } : a
            ));
            setEditingActivity(null);
          }}
        />
      )}

      {/* Activity Grading Modal */}
      {gradingActivity && (
        <ActivityGradesModal
          activity={gradingActivity}
          onClose={() => setGradingActivity(null)}
          onSuccess={(updatedActivity) => {
            setActivities(activities.map(a => 
              a.id === gradingActivity.id ? { ...a, ...updatedActivity } : a
            ));
            setGradingActivity(null);
          }}
        />
      )}
    </div>
  );
}