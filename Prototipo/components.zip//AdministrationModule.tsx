import { useState } from 'react';
import { 
  ChevronLeft, 
  Users, 
  GraduationCap, 
  BookOpen, 
  Settings,
  Plus,
  Edit,
  Shield
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { UserManagement } from './UserManagement';
import { GradeManagement } from './GradeManagement';
import { StudentManagement } from './StudentManagement';
import { SystemSettings } from './SystemSettings';

const adminModules = [
  {
    id: 'users',
    title: 'Gestión de Usuarios',
    description: 'Administrar usuarios y roles',
    icon: Users,
    color: 'bg-blue-500',
    permission: 'manage_users'
  },
  {
    id: 'grades_config',
    title: 'Configurar Grados',
    description: 'Administrar grados y secciones',
    icon: GraduationCap,
    color: 'bg-green-500',
    permission: 'manage_grades'
  },
  {
    id: 'student_admin',
    title: 'Administrar Estudiantes',
    description: 'Crear, editar y asignar estudiantes',
    icon: BookOpen,
    color: 'bg-purple-500',
    permission: 'edit_students'
  },
  {
    id: 'system',
    title: 'Configuración del Sistema',
    description: 'Ajustes generales del sistema',
    icon: Settings,
    color: 'bg-gray-500',
    permission: 'manage_users'
  }
];

export function AdministrationModule({ user, onBack }) {
  const [activeSubModule, setActiveSubModule] = useState('dashboard');

  const hasPermission = (permission) => {
    return user.permissions?.includes(permission) || user.permissions?.includes('view_all');
  };

  const availableModules = adminModules.filter(module => hasPermission(module.permission));

  const renderSubModule = () => {
    switch (activeSubModule) {
      case 'users':
        return <UserManagement user={user} onBack={() => setActiveSubModule('dashboard')} />;
      case 'grades_config':
        return <GradeManagement user={user} onBack={() => setActiveSubModule('dashboard')} />;
      case 'student_admin':
        return <StudentManagement user={user} onBack={() => setActiveSubModule('dashboard')} />;
      case 'system':
        return <SystemSettings user={user} onBack={() => setActiveSubModule('dashboard')} />;
      default:
        return (
          <div className="space-y-6">
            {/* Header */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <div className="flex items-center mb-4">
                <div className="w-12 h-12 bg-gray-500 rounded-xl flex items-center justify-center mr-4">
                  <Shield className="w-6 h-6 text-white" />
                </div>
                <div>
                  <h2 className="text-2xl font-semibold text-gray-900">Panel de Administración</h2>
                  <p className="text-gray-600">Gestiona usuarios, configuraciones y permisos del sistema</p>
                </div>
              </div>
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <div className="flex items-center">
                  <Shield className="w-5 h-5 text-blue-600 mr-2" />
                  <div>
                    <p className="font-medium text-blue-900">Usuario: {user.name}</p>
                    <p className="text-sm text-blue-600">Rol: {user.role}</p>
                  </div>
                </div>
              </div>
            </div>

            {/* Admin Modules Grid */}
            <div className="grid grid-cols-1 gap-4">
              {availableModules.map((module) => {
                const IconComponent = module.icon;
                return (
                  <button
                    key={module.id}
                    onClick={() => setActiveSubModule(module.id)}
                    className="bg-white rounded-2xl p-6 shadow-sm text-left transition-all duration-200 hover:shadow-md active:scale-95"
                  >
                    <div className="flex items-center">
                      <div className={`w-12 h-12 ${module.color} rounded-xl flex items-center justify-center mr-4`}>
                        <IconComponent className="w-6 h-6 text-white" />
                      </div>
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 mb-1">
                          {module.title}
                        </h3>
                        <p className="text-sm text-gray-600">
                          {module.description}
                        </p>
                      </div>
                      <div className="w-6 h-6 bg-gray-100 rounded-full flex items-center justify-center">
                        <Edit className="w-4 h-4 text-gray-500" />
                      </div>
                    </div>
                  </button>
                );
              })}
            </div>

            {availableModules.length === 0 && (
              <div className="text-center py-12">
                <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Shield className="w-8 h-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">
                  Sin permisos administrativos
                </h3>
                <p className="text-gray-600">
                  No tienes permisos para acceder a los módulos administrativos
                </p>
              </div>
            )}
          </div>
        );
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="flex items-center p-4">
          <button onClick={onBack} className="mr-3 p-1">
            <ChevronLeft className="w-6 h-6 text-blue-500" />
          </button>
          <h1 className="text-xl font-semibold text-gray-900">
            {activeSubModule === 'dashboard' ? 'Administración' : 
             availableModules.find(m => m.id === activeSubModule)?.title || 'Administración'}
          </h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {renderSubModule()}
      </div>

      {/* Bottom padding */}
      <div className="h-6"></div>
    </div>
  );
}