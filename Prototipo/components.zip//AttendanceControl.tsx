import { useState } from 'react';
import { ChevronLeft, QrCode, Camera, Users, Clock, Calendar, Filter } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { getAvatarByIndex } from '../utils/avatars';

const mockAttendanceData = {
  present: [
    {
      id: 1,
      name: 'Ana María López',
      grade: '5to Primaria',
      section: 'A',
      entryTime: '07:30',
      avatar: getAvatarByIndex(0, 'students')
    },
    {
      id: 2,
      name: 'María José Hernández',
      grade: '2do Primaria',
      section: 'A',
      entryTime: '07:45',
      avatar: getAvatarByIndex(1, 'students')
    },
    {
      id: 3,
      name: 'Diego Alexander Ruiz',
      grade: '1ro Secundaria',
      section: 'C',
      entryTime: '07:35',
      avatar: getAvatarByIndex(2, 'students')
    },
    {
      id: 6,
      name: 'Luis Fernando Morales',
      grade: '3ro Primaria',
      section: 'B',
      entryTime: '07:40',
      avatar: getAvatarByIndex(3, 'students')
    },
    {
      id: 7,
      name: 'Carmen Elena Rodríguez',
      grade: '4to Primaria',
      section: 'A',
      entryTime: '07:25',
      avatar: getAvatarByIndex(4, 'students')
    }
  ],
  departed: [
    {
      id: 4,
      name: 'Carlos Roberto Mendez',
      grade: '3ro Secundaria',
      section: 'B',
      exitTime: '12:30',
      authorizedBy: 'María González',
      avatar: getAvatarByIndex(5, 'students')
    },
    {
      id: 5,
      name: 'Sofía Isabella García',
      grade: '4to Primaria',
      section: 'B',
      exitTime: '15:00',
      authorizedBy: 'Sistema',
      avatar: getAvatarByIndex(6, 'students')
    }
  ]
};

const mockGrades = [
  { name: 'Preprimaria', sections: ['A', 'B'] },
  { name: '1ro Primaria', sections: ['A', 'B', 'C'] },
  { name: '2do Primaria', sections: ['A', 'B'] },
  { name: '3ro Primaria', sections: ['A', 'B', 'C'] },
  { name: '4to Primaria', sections: ['A', 'B'] },
  { name: '5to Primaria', sections: ['A', 'B'] },
  { name: '6to Primaria', sections: ['A', 'B'] },
  { name: '1ro Secundaria', sections: ['A', 'B', 'C'] },
  { name: '2do Secundaria', sections: ['A', 'B'] },
  { name: '3ro Secundaria', sections: ['A', 'B'] }
];

export function AttendanceControl({ user, onBack }) {
  const [showQRScanner, setShowQRScanner] = useState(false);
  const [lastScanned, setLastScanned] = useState(null);
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [selectedSection, setSelectedSection] = useState('all');
  const [showFilters, setShowFilters] = useState(false);

  // Get available sections based on selected grade
  const availableSections = selectedGrade === 'all' 
    ? []
    : mockGrades.find(g => g.name === selectedGrade)?.sections || [];

  const filterStudents = (students) => {
    return students.filter(student => {
      const matchesGrade = selectedGrade === 'all' || student.grade === selectedGrade;
      const matchesSection = selectedSection === 'all' || student.section === selectedSection;
      return matchesGrade && matchesSection;
    });
  };

  const filteredPresentStudents = filterStudents(mockAttendanceData.present);
  const filteredDepartedStudents = filterStudents(mockAttendanceData.departed);

  const currentTime = new Date().toLocaleTimeString('es-GT', { 
    hour: '2-digit', 
    minute: '2-digit' 
  });

  const currentDate = new Date().toLocaleDateString('es-GT', { 
    weekday: 'long', 
    year: 'numeric', 
    month: 'long', 
    day: 'numeric' 
  });

  const handleQRScan = () => {
    setShowQRScanner(true);
    // Simulate QR scan after 2 seconds
    setTimeout(() => {
      const mockStudent = {
        name: 'Juan Carlos Pérez',
        grade: '4to Primaria',
        section: 'B',
        action: 'entrada'
      };
      setLastScanned(mockStudent);
      setShowQRScanner(false);
      
      // Show success toast
      setTimeout(() => setLastScanned(null), 3000);
    }, 2000);
  };

  if (showQRScanner) {
    return (
      <div className="min-h-screen bg-black relative">
        {/* QR Scanner Overlay */}
        <div className="absolute inset-0 flex items-center justify-center">
          <div className="relative">
            {/* Scanner Frame */}
            <div className="w-64 h-64 border-4 border-white rounded-2xl relative">
              <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-blue-500 rounded-tl-2xl"></div>
              <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-blue-500 rounded-tr-2xl"></div>
              <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-blue-500 rounded-bl-2xl"></div>
              <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-blue-500 rounded-br-2xl"></div>
              
              {/* Scanning animation */}
              <div className="absolute inset-4 border border-blue-500/30 rounded-lg animate-pulse"></div>
            </div>
          </div>
        </div>

        {/* Header */}
        <div className="absolute top-0 left-0 right-0 p-4 bg-black/50">
          <div className="flex items-center justify-between">
            <button 
              onClick={() => setShowQRScanner(false)}
              className="text-white text-lg"
            >
              <ChevronLeft className="w-6 h-6" />
            </button>
            <h1 className="text-white text-lg font-semibold">Escanear Código QR</h1>
            <div></div>
          </div>
        </div>

        {/* Instructions */}
        <div className="absolute bottom-20 left-0 right-0 p-6 text-center">
          <h2 className="text-white text-xl font-semibold mb-2">
            Escanea el código QR
          </h2>
          <p className="text-white/80">
            Coloca el código dentro del marco para registrar entrada o salida
          </p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="flex items-center p-4">
          <button onClick={onBack} className="mr-3 p-1">
            <ChevronLeft className="w-6 h-6 text-blue-500" />
          </button>
          <h1 className="text-xl font-semibold text-gray-900">Control de Asistencia</h1>
        </div>
      </div>

      {/* Success Toast */}
      {lastScanned && (
        <div className="absolute top-20 left-4 right-4 bg-green-500 text-white p-4 rounded-xl shadow-lg z-20 animate-in slide-in-from-top">
          <div className="flex items-center">
            <div className="w-8 h-8 bg-white/20 rounded-full flex items-center justify-center mr-3">
              ✓
            </div>
            <div>
              <p className="font-semibold">
                {lastScanned.action === 'entrada' ? 'Entrada registrada' : 'Salida registrada'}
              </p>
              <p className="text-sm opacity-90">
                {lastScanned.name} - {lastScanned.grade}
              </p>
            </div>
          </div>
        </div>
      )}

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Current Time & Date */}
        <Card className="shadow-sm border-0 rounded-2xl bg-blue-50">
          <CardContent className="p-4">
            <div className="text-center">
              <div className="flex items-center justify-center mb-2">
                <Clock className="w-6 h-6 text-blue-600 mr-2" />
                <h2 className="text-2xl font-bold text-blue-800">{currentTime}</h2>
              </div>
              <p className="text-blue-600 capitalize">{currentDate}</p>
            </div>
          </CardContent>
        </Card>

        {/* Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="shadow-sm border-0 rounded-2xl">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-green-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                <Users className="w-6 h-6 text-green-600" />
              </div>
              <p className="text-2xl font-bold text-gray-900">
                {filteredPresentStudents.length}
              </p>
              <p className="text-sm text-gray-600">En el colegio</p>
            </CardContent>
          </Card>

          <Card className="shadow-sm border-0 rounded-2xl">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-orange-100 rounded-xl flex items-center justify-center mx-auto mb-2">
                <Calendar className="w-6 h-6 text-orange-600" />
              </div>
              <p className="text-2xl font-bold text-gray-900">
                {filteredDepartedStudents.length}
              </p>
              <p className="text-sm text-gray-600">Ya salieron</p>
            </CardContent>
          </Card>
        </div>

        {/* Filters */}
        <Card className="shadow-sm border-0 rounded-2xl">
          <CardContent className="p-4">
            <div className="flex items-center justify-between mb-4">
              <h3 className="font-medium text-gray-900">Filtros de Asistencia</h3>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setShowFilters(!showFilters)}
                className="rounded-lg"
              >
                <Filter className="w-4 h-4 mr-2" />
                {showFilters ? 'Ocultar' : 'Mostrar'}
              </Button>
            </div>
            
            {showFilters && (
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filtrar por Grado
                  </label>
                  <Select value={selectedGrade} onValueChange={(value) => {
                    setSelectedGrade(value);
                    setSelectedSection('all');
                  }}>
                    <SelectTrigger className="h-10 rounded-lg border-gray-200">
                      <SelectValue placeholder="Todos los grados" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todos los grados</SelectItem>
                      {mockGrades.map((grade, index) => (
                        <SelectItem key={index} value={grade.name}>
                          {grade.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Filtrar por Sección
                  </label>
                  <Select 
                    value={selectedSection} 
                    onValueChange={setSelectedSection}
                    disabled={selectedGrade === 'all'}
                  >
                    <SelectTrigger className="h-10 rounded-lg border-gray-200">
                      <SelectValue placeholder="Todas las secciones" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">Todas las secciones</SelectItem>
                      {availableSections.map((section) => (
                        <SelectItem key={section} value={section}>
                          Sección {section}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                  {selectedGrade === 'all' && (
                    <p className="text-xs text-gray-500 mt-1">
                      Selecciona un grado primero
                    </p>
                  )}
                </div>
              </div>
            )}

            {(selectedGrade !== 'all' || selectedSection !== 'all') && (
              <div className="mt-3 p-3 bg-blue-50 rounded-lg">
                <p className="text-sm text-blue-800">
                  <strong>Filtro activo:</strong> 
                  {selectedGrade !== 'all' && ` ${selectedGrade}`}
                  {selectedSection !== 'all' && ` - Sección ${selectedSection}`}
                </p>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => {
                    setSelectedGrade('all');
                    setSelectedSection('all');
                  }}
                  className="mt-2 text-xs rounded-lg"
                >
                  Limpiar filtros
                </Button>
              </div>
            )}
          </CardContent>
        </Card>

        {/* QR Scanner Button */}
        <Button 
          onClick={handleQRScan}
          className="w-full h-16 bg-blue-500 hover:bg-blue-600 text-white rounded-2xl text-lg font-semibold"
        >
          <QrCode className="w-8 h-8 mr-3" />
          Escanear Código QR
        </Button>

        {/* Attendance Lists */}
        <Tabs defaultValue="present" className="w-full">
          <TabsList className="grid w-full grid-cols-2 bg-gray-100 rounded-xl">
            <TabsTrigger value="present" className="rounded-lg">
              Presentes ({filteredPresentStudents.length})
            </TabsTrigger>
            <TabsTrigger value="departed" className="rounded-lg">
              Salieron ({filteredDepartedStudents.length})
            </TabsTrigger>
          </TabsList>

          <TabsContent value="present" className="space-y-3 mt-4">
            {filteredPresentStudents.map((student) => (
              <Card key={student.id} className="shadow-sm border-0 rounded-2xl">
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 mr-3">
                      <img
                        src={student.avatar}
                        alt={student.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{student.name}</h3>
                      <p className="text-sm text-gray-600">
                        {student.grade} - Sección {student.section}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge className="bg-green-500 hover:bg-green-600 mb-1">
                        Presente
                      </Badge>
                      <p className="text-sm text-gray-600">
                        Entrada: {student.entryTime}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}
          </TabsContent>

          <TabsContent value="departed" className="space-y-3 mt-4">
            {filteredDepartedStudents.map((student) => (
              <Card key={student.id} className="shadow-sm border-0 rounded-2xl">
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 mr-3">
                      <img
                        src={student.avatar}
                        alt={student.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{student.name}</h3>
                      <p className="text-sm text-gray-600">
                        {student.grade} - Sección {student.section}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant="secondary" className="mb-1 bg-gray-500 text-white hover:bg-gray-600">
                        Salió
                      </Badge>
                      <p className="text-sm text-gray-600">
                        Salida: {student.exitTime}
                      </p>
                      <p className="text-xs text-gray-500">
                        Autorizado por: {student.authorizedBy}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {filteredPresentStudents.length === 0 && (
              <div className="text-center py-8">
                <Users className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">
                  {selectedGrade !== 'all' || selectedSection !== 'all' 
                    ? 'No hay estudiantes presentes que coincidan con el filtro' 
                    : 'No hay estudiantes presentes'
                  }
                </p>
              </div>
            )}
          </TabsContent>

          <TabsContent value="departed" className="space-y-3 mt-4">
            {filteredDepartedStudents.map((student) => (
              <Card key={student.id} className="shadow-sm border-0 rounded-2xl">
                <CardContent className="p-4">
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 mr-3">
                      <img
                        src={student.avatar}
                        alt={student.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h3 className="font-semibold text-gray-900">{student.name}</h3>
                      <p className="text-sm text-gray-600">
                        {student.grade} - Sección {student.section}
                      </p>
                    </div>
                    <div className="text-right">
                      <Badge variant="secondary" className="mb-1 bg-gray-500 text-white hover:bg-gray-600">
                        Salió
                      </Badge>
                      <p className="text-sm text-gray-600">
                        Salida: {student.exitTime}
                      </p>
                      <p className="text-xs text-gray-500">
                        Autorizado por: {student.authorizedBy}
                      </p>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))}

            {filteredDepartedStudents.length === 0 && (
              <div className="text-center py-8">
                <Calendar className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">
                  {selectedGrade !== 'all' || selectedSection !== 'all' 
                    ? 'No hay estudiantes que hayan salido que coincidan con el filtro' 
                    : 'No hay estudiantes que hayan salido'
                  }
                </p>
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>

      {/* Bottom padding */}
      <div className="h-6"></div>
    </div>
  );
}