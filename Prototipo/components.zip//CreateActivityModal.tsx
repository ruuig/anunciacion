import { useState, useEffect } from 'react';
import { X, Calendar, Target, Book, Users } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';

const activityTypes = ['Examen', 'Tarea', 'Proyecto', 'Laboratorio', 'Presentación', 'Quiz'];
const subjects = ['Matemáticas', 'Español', 'Ciencias Naturales', 'Estudios Sociales', 'Inglés'];
const sections = ['A', 'B', 'C'];
const periods = ['Primer Bimestre', 'Segundo Bimestre', 'Tercer Bimestre', 'Cuarto Bimestre'];

export function CreateActivityModal({ activity, availableGrades, onClose, onSuccess }) {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    subject: '',
    grade: '',
    section: '',
    period: '',
    type: '',
    points: '',
    date: '',
    description: ''
  });

  useEffect(() => {
    if (activity) {
      setFormData({
        name: activity.name || '',
        subject: activity.subject || '',
        grade: activity.grade || '',
        section: activity.section || '',
        period: activity.period || '',
        type: activity.type || '',
        points: activity.points?.toString() || '',
        date: activity.date || '',
        description: activity.description || ''
      });
    }
  }, [activity]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    const activityData = {
      ...formData,
      points: parseInt(formData.points, 10)
    };
    
    onSuccess(activityData);
    setIsLoading(false);
    onClose();
  };

  const isValid = formData.name && formData.subject && formData.grade && 
                 formData.section && formData.period && formData.type && 
                 formData.points && formData.date;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center mr-3">
              <Target className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                {activity ? 'Editar Actividad' : 'Crear Nueva Actividad'}
              </h2>
              <p className="text-sm text-gray-600">
                {activity ? 'Modifica los detalles de la actividad' : 'Planifica una nueva evaluación'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 max-h-[70vh] overflow-y-auto space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">Información Básica</h3>
            
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre de la actividad *
              </label>
              <Input
                type="text"
                placeholder="Ej: Examen Parcial - Fracciones"
                value={formData.name}
                onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Tipo de actividad *
                </label>
                <Select value={formData.type} onValueChange={(value) => setFormData({ ...formData, type: value })}>
                  <SelectTrigger className="h-12 rounded-xl border-gray-200">
                    <SelectValue placeholder="Selecciona el tipo" />
                  </SelectTrigger>
                  <SelectContent>
                    {activityTypes.map((type) => (
                      <SelectItem key={type} value={type}>
                        {type}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Materia *
                </label>
                <Select value={formData.subject} onValueChange={(value) => setFormData({ ...formData, subject: value })}>
                  <SelectTrigger className="h-12 rounded-xl border-gray-200">
                    <SelectValue placeholder="Selecciona la materia" />
                  </SelectTrigger>
                  <SelectContent>
                    {subjects.map((subject) => (
                      <SelectItem key={subject} value={subject}>
                        {subject}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>

          {/* Assignment Details */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">Asignación</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Grado *
                </label>
                <Select value={formData.grade} onValueChange={(value) => setFormData({ ...formData, grade: value })}>
                  <SelectTrigger className="h-12 rounded-xl border-gray-200">
                    <SelectValue placeholder="Selecciona el grado" />
                  </SelectTrigger>
                  <SelectContent>
                    {availableGrades.map((grade) => (
                      <SelectItem key={grade} value={grade}>
                        {grade}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Sección *
                </label>
                <Select value={formData.section} onValueChange={(value) => setFormData({ ...formData, section: value })}>
                  <SelectTrigger className="h-12 rounded-xl border-gray-200">
                    <SelectValue placeholder="Selecciona la sección" />
                  </SelectTrigger>
                  <SelectContent>
                    {sections.map((section) => (
                      <SelectItem key={section} value={section}>
                        Sección {section}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Periodo *
              </label>
              <Select value={formData.period} onValueChange={(value) => setFormData({ ...formData, period: value })}>
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Selecciona el periodo" />
                </SelectTrigger>
                <SelectContent>
                  {periods.map((period) => (
                    <SelectItem key={period} value={period}>
                      {period}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Evaluation Details */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">Detalles de Evaluación</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Puntos totales *
                </label>
                <Input
                  type="number"
                  min="1"
                  max="100"
                  placeholder="25"
                  value={formData.points}
                  onChange={(e) => setFormData({ ...formData, points: e.target.value })}
                  className="h-12 rounded-xl border-gray-200"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fecha de aplicación *
                </label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Descripción (opcional)
              </label>
              <Textarea
                placeholder="Descripción de la actividad, objetivos, instrucciones especiales..."
                value={formData.description}
                onChange={(e) => setFormData({ ...formData, description: e.target.value })}
                className="min-h-[100px] rounded-xl border-gray-200"
              />
            </div>
          </div>

          {/* Preview */}
          {isValid && (
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <h4 className="font-medium text-blue-900 mb-2">Vista Previa</h4>
              <div className="space-y-1 text-sm text-blue-800">
                <p><strong>{formData.name}</strong> - {formData.type}</p>
                <p>{formData.subject} • {formData.grade} - Sección {formData.section}</p>
                <p>{formData.period} • {formData.points} puntos • {formData.date}</p>
              </div>
            </div>
          )}
        </form>

        {/* Actions */}
        <div className="flex justify-between p-6 border-t border-gray-100">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            className="rounded-xl"
          >
            Cancelar
          </Button>

          <Button
            onClick={handleSubmit}
            disabled={!isValid || isLoading}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            {isLoading ? 'Guardando...' : activity ? 'Actualizar Actividad' : 'Crear Actividad'}
          </Button>
        </div>
      </div>
    </div>
  );
}