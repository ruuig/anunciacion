import { useState, useEffect } from 'react';
import { X, Plus, Trash2, GraduationCap } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Badge } from './ui/badge';

const educationLevels = [
  { value: 'Preprimaria', label: 'Preprimaria' },
  { value: 'Primaria', label: 'Primaria' },
  { value: 'Secundaria', label: 'Secundaria' }
];

const defaultSubjects = {
  'Preprimaria': ['Matemáticas Básicas', 'Español', 'Inglés', 'Arte', 'Educación Física'],
  'Primaria': ['Matemáticas', 'Español', 'Ciencias Naturales', 'Estudios Sociales', 'Inglés', 'Educación Física'],
  'Secundaria': ['Matemáticas', 'Español', 'Ciencias Naturales', 'Estudios Sociales', 'Inglés', 'Educación Física', 'Computación', 'Arte']
};

export function CreateGradeModal({ grade, onClose, onSuccess }) {
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    name: '',
    level: '',
    sections: ['A'],
    subjects: [],
    ageRange: ''
  });
  const [newSection, setNewSection] = useState('');
  const [newSubject, setNewSubject] = useState('');

  useEffect(() => {
    if (grade) {
      setFormData({
        name: grade.name,
        level: grade.level,
        sections: [...grade.sections],
        subjects: [...grade.subjects],
        ageRange: grade.ageRange
      });
    }
  }, [grade]);

  const handleLevelChange = (level) => {
    setFormData({
      ...formData,
      level,
      subjects: defaultSubjects[level] || []
    });
  };

  const addSection = () => {
    if (newSection && !formData.sections.includes(newSection.toUpperCase())) {
      setFormData({
        ...formData,
        sections: [...formData.sections, newSection.toUpperCase()]
      });
      setNewSection('');
    }
  };

  const removeSection = (sectionToRemove) => {
    if (formData.sections.length > 1) {
      setFormData({
        ...formData,
        sections: formData.sections.filter(s => s !== sectionToRemove)
      });
    }
  };

  const addSubject = () => {
    if (newSubject && !formData.subjects.includes(newSubject)) {
      setFormData({
        ...formData,
        subjects: [...formData.subjects, newSubject]
      });
      setNewSubject('');
    }
  };

  const removeSubject = (subjectToRemove) => {
    setFormData({
      ...formData,
      subjects: formData.subjects.filter(s => s !== subjectToRemove)
    });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    onSuccess(formData);
    setIsLoading(false);
    onClose();
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div className="flex items-center">
            <div className="w-10 h-10 bg-blue-500 rounded-xl flex items-center justify-center mr-3">
              <GraduationCap className="w-5 h-5 text-white" />
            </div>
            <div>
              <h2 className="text-xl font-semibold text-gray-900">
                {grade ? 'Editar Grado' : 'Crear Nuevo Grado'}
              </h2>
              <p className="text-sm text-gray-600">
                {grade ? 'Modifica la información del grado' : 'Configura un nuevo grado académico'}
              </p>
            </div>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Content */}
        <form onSubmit={handleSubmit} className="p-6 max-h-[70vh] overflow-y-auto space-y-6">
          {/* Basic Information */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">Información Básica</h3>
            
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nombre del grado *
                </label>
                <Input
                  type="text"
                  placeholder="Ej: 1ro Primaria"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="h-12 rounded-xl border-gray-200"
                  required
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Nivel educativo *
                </label>
                <Select value={formData.level} onValueChange={handleLevelChange} required>
                  <SelectTrigger className="h-12 rounded-xl border-gray-200">
                    <SelectValue placeholder="Selecciona el nivel" />
                  </SelectTrigger>
                  <SelectContent>
                    {educationLevels.map((level) => (
                      <SelectItem key={level.value} value={level.value}>
                        {level.label}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rango de edad
              </label>
              <Input
                type="text"
                placeholder="Ej: 6-7 años"
                value={formData.ageRange}
                onChange={(e) => setFormData({ ...formData, ageRange: e.target.value })}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>
          </div>

          {/* Sections */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">Secciones</h3>
            
            <div className="flex flex-wrap gap-2 mb-4">
              {formData.sections.map((section) => (
                <div key={section} className="flex items-center bg-blue-50 rounded-lg px-3 py-2">
                  <span className="text-sm font-medium text-blue-900">Sección {section}</span>
                  {formData.sections.length > 1 && (
                    <button
                      type="button"
                      onClick={() => removeSection(section)}
                      className="ml-2 text-blue-600 hover:text-blue-800"
                    >
                      <X className="w-4 h-4" />
                    </button>
                  )}
                </div>
              ))}
            </div>

            <div className="flex space-x-2">
              <Input
                type="text"
                placeholder="Nueva sección (A, B, C...)"
                value={newSection}
                onChange={(e) => setNewSection(e.target.value.toUpperCase())}
                className="h-10 rounded-lg border-gray-200"
                maxLength={1}
              />
              <Button
                type="button"
                onClick={addSection}
                disabled={!newSection || formData.sections.includes(newSection.toUpperCase())}
                className="h-10 px-4 rounded-lg"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>

          {/* Subjects */}
          <div className="space-y-4">
            <h3 className="font-semibold text-gray-900">Materias</h3>
            
            {formData.level && (
              <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
                <p className="text-sm text-blue-800 mb-2">
                  Materias sugeridas para {formData.level}:
                </p>
                <div className="flex flex-wrap gap-1">
                  {defaultSubjects[formData.level]?.map((subject, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {subject}
                    </Badge>
                  ))}
                </div>
              </div>
            )}
            
            <div className="flex flex-wrap gap-2 mb-4 max-h-32 overflow-y-auto">
              {formData.subjects.map((subject) => (
                <div key={subject} className="flex items-center bg-green-50 rounded-lg px-3 py-2">
                  <span className="text-sm font-medium text-green-900">{subject}</span>
                  <button
                    type="button"
                    onClick={() => removeSubject(subject)}
                    className="ml-2 text-green-600 hover:text-green-800"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              ))}
            </div>

            <div className="flex space-x-2">
              <Input
                type="text"
                placeholder="Nueva materia"
                value={newSubject}
                onChange={(e) => setNewSubject(e.target.value)}
                className="h-10 rounded-lg border-gray-200"
              />
              <Button
                type="button"
                onClick={addSubject}
                disabled={!newSubject || formData.subjects.includes(newSubject)}
                className="h-10 px-4 rounded-lg"
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </form>

        {/* Actions */}
        <div className="flex justify-between p-6 border-t border-gray-100">
          <Button
            type="button"
            variant="outline"
            onClick={onClose}
            className="rounded-xl"
          >
            Cancelar
          </Button>

          <Button
            onClick={handleSubmit}
            disabled={!formData.name || !formData.level || isLoading}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            {isLoading ? 'Guardando...' : grade ? 'Actualizar Grado' : 'Crear Grado'}
          </Button>
        </div>
      </div>
    </div>
  );
}