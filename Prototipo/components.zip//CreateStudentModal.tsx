import { useState, useEffect } from 'react';
import { X, User, Mail, Phone, MapPin, Users, GraduationCap, Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

export function CreateStudentModal({ student, grades, onClose, onSuccess }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    // Student Info
    name: '',
    dpi: '',
    birthDate: '',
    phone: '',
    email: '',
    address: '',
    
    // Academic Info
    grade: '',
    section: '',
    
    // Parent/Guardian Info
    parentName: '',
    parentPhone: '',
    parentEmail: '',
    parentAddress: '',
    relationship: 'Padre/Madre'
  });

  const [availableSections, setAvailableSections] = useState([]);

  useEffect(() => {
    if (student) {
      setFormData({
        name: student.name || '',
        dpi: student.dpi || '',
        birthDate: student.birthDate || '',
        phone: student.phone || '',
        email: student.email || '',
        address: student.address || '',
        grade: student.grade || '',
        section: student.section || '',
        parentName: student.parentName || '',
        parentPhone: student.parentPhone || '',
        parentEmail: student.parentEmail || '',
        parentAddress: student.parentAddress || student.address || '',
        relationship: student.relationship || 'Padre/Madre'
      });
    }
  }, [student]);

  useEffect(() => {
    if (formData.grade) {
      const selectedGrade = grades.find(g => g.name === formData.grade);
      setAvailableSections(selectedGrade?.sections || []);
      if (!selectedGrade?.sections.includes(formData.section)) {
        setFormData(prev => ({ ...prev, section: '' }));
      }
    } else {
      setAvailableSections([]);
    }
  }, [formData.grade, grades]);

  const validateStep = (step) => {
    switch (step) {
      case 1:
        return formData.name && formData.dpi && formData.birthDate;
      case 2:
        return formData.grade && formData.section;
      case 3:
        return formData.parentName && formData.parentPhone;
      default:
        return true;
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    onSuccess(formData);
    setIsLoading(false);
    onClose();
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre completo del estudiante *
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="Ej: Ana María López García"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                DPI/Documento de identidad *
              </label>
              <Input
                type="text"
                placeholder="1234567890101"
                value={formData.dpi}
                onChange={(e) => setFormData({ ...formData, dpi: e.target.value })}
                className="h-12 rounded-xl border-gray-200"
                maxLength={13}
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha de nacimiento *
              </label>
              <div className="relative">
                <Calendar className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="date"
                  value={formData.birthDate}
                  onChange={(e) => setFormData({ ...formData, birthDate: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Teléfono (opcional)
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="tel"
                  placeholder="+502 1234-5678"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Correo electrónico (opcional)
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="email"
                  placeholder="estudiante@ejemplo.com"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Dirección
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                <Textarea
                  placeholder="Dirección completa del estudiante"
                  value={formData.address}
                  onChange={(e) => setFormData({ ...formData, address: e.target.value })}
                  className="pl-10 min-h-[80px] rounded-xl border-gray-200"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <GraduationCap className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Asignación Académica
              </h3>
              <p className="text-gray-600">
                Selecciona el grado y sección para el estudiante
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Grado *
              </label>
              <Select 
                value={formData.grade} 
                onValueChange={(value) => setFormData({ ...formData, grade: value, section: '' })}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Selecciona el grado" />
                </SelectTrigger>
                <SelectContent>
                  {grades.map((grade) => (
                    <SelectItem key={grade.id} value={grade.name}>
                      {grade.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sección *
              </label>
              <Select 
                value={formData.section} 
                onValueChange={(value) => setFormData({ ...formData, section: value })}
                disabled={!formData.grade}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Selecciona la sección" />
                </SelectTrigger>
                <SelectContent>
                  {availableSections.map((section) => (
                    <SelectItem key={section} value={section}>
                      Sección {section}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
              {!formData.grade && (
                <p className="text-sm text-gray-500 mt-1">
                  Primero selecciona un grado
                </p>
              )}
            </div>

            {formData.grade && formData.section && (
              <div className="bg-green-50 border border-green-200 rounded-xl p-4">
                <div className="flex items-center">
                  <div className="w-10 h-10 bg-green-500 rounded-full flex items-center justify-center mr-3">
                    ✓
                  </div>
                  <div>
                    <p className="font-medium text-green-900">
                      Asignación confirmada
                    </p>
                    <p className="text-sm text-green-700">
                      El estudiante será asignado a {formData.grade} - Sección {formData.section}
                    </p>
                  </div>
                </div>
              </div>
            )}
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Users className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Información del Padre/Tutor
              </h3>
              <p className="text-gray-600">
                Datos de contacto del responsable del estudiante
              </p>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Parentesco
              </label>
              <Select 
                value={formData.relationship} 
                onValueChange={(value) => setFormData({ ...formData, relationship: value })}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Selecciona el parentesco" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="Padre/Madre">Padre/Madre</SelectItem>
                  <SelectItem value="Abuelo/Abuela">Abuelo/Abuela</SelectItem>
                  <SelectItem value="Tío/Tía">Tío/Tía</SelectItem>
                  <SelectItem value="Tutor Legal">Tutor Legal</SelectItem>
                  <SelectItem value="Otro">Otro</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre completo del responsable *
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="Ej: Carlos López Martínez"
                  value={formData.parentName}
                  onChange={(e) => setFormData({ ...formData, parentName: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Teléfono del responsable *
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="tel"
                  placeholder="+502 2345-6789"
                  value={formData.parentPhone}
                  onChange={(e) => setFormData({ ...formData, parentPhone: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Correo del responsable (opcional)
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="email"
                  placeholder="padre@ejemplo.com"
                  value={formData.parentEmail}
                  onChange={(e) => setFormData({ ...formData, parentEmail: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Dirección del responsable
              </label>
              <div className="relative">
                <MapPin className="absolute left-3 top-3 text-gray-400 w-5 h-5" />
                <Textarea
                  placeholder="Dirección del padre/tutor (si es diferente a la del estudiante)"
                  value={formData.parentAddress}
                  onChange={(e) => setFormData({ ...formData, parentAddress: e.target.value })}
                  className="pl-10 min-h-[80px] rounded-xl border-gray-200"
                />
              </div>
              <div className="mt-2">
                <Button
                  type="button"
                  variant="outline"
                  size="sm"
                  onClick={() => setFormData({ ...formData, parentAddress: formData.address })}
                  className="text-xs"
                >
                  Usar misma dirección del estudiante
                </Button>
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Resumen del Estudiante</h3>
              <p className="text-gray-600">Revisa la información antes de guardar</p>
            </div>

            <div className="space-y-4">
              <Card className="border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-base">Información del Estudiante</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Nombre:</span>
                    <span className="font-medium">{formData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">DPI:</span>
                    <span className="font-medium">{formData.dpi}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Fecha de nacimiento:</span>
                    <span className="font-medium">{formData.birthDate}</span>
                  </div>
                  {formData.phone && (
                    <div className="flex justify-between">
                      <span className="text-gray-600">Teléfono:</span>
                      <span className="font-medium">{formData.phone}</span>
                    </div>
                  )}
                </CardContent>
              </Card>

              <Card className="border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-base">Asignación Académica</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Grado:</span>
                    <span className="font-medium">{formData.grade}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Sección:</span>
                    <span className="font-medium">Sección {formData.section}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-base">Responsable</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2 text-sm">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Nombre:</span>
                    <span className="font-medium">{formData.parentName}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Parentesco:</span>
                    <span className="font-medium">{formData.relationship}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Teléfono:</span>
                    <span className="font-medium">{formData.parentPhone}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              {student ? 'Editar Estudiante' : 'Crear Nuevo Estudiante'}
            </h2>
            <p className="text-sm text-gray-600">Paso {currentStep} de 4</p>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Progress */}
        <div className="px-6 py-4">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / 4) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Content */}
        <div className="px-6 py-4 max-h-[60vh] overflow-y-auto">
          {renderStep()}
        </div>

        {/* Actions */}
        <div className="flex justify-between p-6 border-t border-gray-100">
          <Button
            variant="outline"
            onClick={() => {
              if (currentStep > 1) {
                setCurrentStep(currentStep - 1);
              } else {
                onClose();
              }
            }}
            className="rounded-xl"
          >
            {currentStep === 1 ? 'Cancelar' : 'Anterior'}
          </Button>

          <Button
            onClick={() => {
              if (currentStep < 4) {
                setCurrentStep(currentStep + 1);
              } else {
                handleSubmit();
              }
            }}
            disabled={!validateStep(currentStep) || isLoading}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            {isLoading ? 'Guardando...' : currentStep === 4 ? (student ? 'Actualizar' : 'Crear Estudiante') : 'Siguiente'}
          </Button>
        </div>
      </div>
    </div>
  );
}