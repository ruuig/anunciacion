import { useState } from 'react';
import { X, User, Mail, Phone, Key, Eye, EyeOff } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Checkbox } from './ui/checkbox';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

const roles = [
  {
    value: 'Director',
    label: 'Director',
    permissions: ['view_all', 'edit_all', 'delete_all', 'manage_users', 'manage_grades', 'manage_students']
  },
  {
    value: 'Secretaria',
    label: 'Secretaria',
    permissions: ['view_students', 'edit_students', 'manage_payments', 'view_reports']
  },
  {
    value: 'Docente',
    label: 'Docente',
    permissions: ['view_students', 'manage_grades', 'view_attendance']
  }
];

const allPermissions = [
  { id: 'view_all', label: 'Ver todo', description: 'Acceso completo de lectura' },
  { id: 'edit_all', label: 'Editar todo', description: 'Acceso completo de edición' },
  { id: 'delete_all', label: 'Eliminar todo', description: 'Capacidad de eliminar registros' },
  { id: 'manage_users', label: 'Gestionar usuarios', description: 'Crear y editar usuarios' },
  { id: 'manage_grades', label: 'Gestionar calificaciones', description: 'Ingresar y editar notas' },
  { id: 'manage_students', label: 'Gestionar estudiantes', description: 'Crear y editar estudiantes' },
  { id: 'view_students', label: 'Ver estudiantes', description: 'Consultar información de estudiantes' },
  { id: 'edit_students', label: 'Editar estudiantes', description: 'Modificar información de estudiantes' },
  { id: 'manage_payments', label: 'Gestionar pagos', description: 'Registrar y consultar pagos' },
  { id: 'view_reports', label: 'Ver reportes', description: 'Generar y consultar reportes' },
  { id: 'view_attendance', label: 'Ver asistencia', description: 'Controlar entrada y salida' }
];

export function CreateUserModal({ onClose, onSuccess }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    phone: '',
    role: '',
    username: '',
    password: '',
    confirmPassword: '',
    permissions: []
  });

  const handleRoleChange = (role) => {
    const selectedRole = roles.find(r => r.value === role);
    setFormData({
      ...formData,
      role,
      permissions: selectedRole ? selectedRole.permissions : []
    });
  };

  const handlePermissionChange = (permissionId, checked) => {
    if (checked) {
      setFormData({
        ...formData,
        permissions: [...formData.permissions, permissionId]
      });
    } else {
      setFormData({
        ...formData,
        permissions: formData.permissions.filter(p => p !== permissionId)
      });
    }
  };

  const generateUsername = () => {
    if (formData.name) {
      const names = formData.name.toLowerCase().split(' ');
      const username = names.join('.');
      setFormData({ ...formData, username });
    }
  };

  const generatePassword = () => {
    const password = Math.random().toString(36).slice(-8);
    setFormData({ ...formData, password, confirmPassword: password });
  };

  const validateStep = (step) => {
    switch (step) {
      case 1:
        return formData.name && formData.email && formData.phone;
      case 2:
        return formData.role && formData.permissions.length > 0;
      case 3:
        return formData.username && formData.password && formData.confirmPassword &&
               formData.password === formData.confirmPassword;
      default:
        return true;
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    onSuccess(formData);
    setIsLoading(false);
    onClose();
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre completo *
              </label>
              <div className="relative">
                <User className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="text"
                  placeholder="Ej: María González"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Correo electrónico *
              </label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="email"
                  placeholder="correo@colegio.edu"
                  value={formData.email}
                  onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Teléfono *
              </label>
              <div className="relative">
                <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
                <Input
                  type="tel"
                  placeholder="+502 1234-5678"
                  value={formData.phone}
                  onChange={(e) => setFormData({ ...formData, phone: e.target.value })}
                  className="pl-10 h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Rol del usuario *
              </label>
              <Select value={formData.role} onValueChange={handleRoleChange}>
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Selecciona un rol" />
                </SelectTrigger>
                <SelectContent>
                  {roles.map((role) => (
                    <SelectItem key={role.value} value={role.value}>
                      {role.label}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Permisos del sistema
              </label>
              <div className="max-h-60 overflow-y-auto space-y-2 border border-gray-200 rounded-xl p-4">
                {allPermissions.map((permission) => (
                  <div key={permission.id} className="flex items-start space-x-3">
                    <Checkbox
                      id={permission.id}
                      checked={formData.permissions.includes(permission.id)}
                      onCheckedChange={(checked) => handlePermissionChange(permission.id, checked)}
                    />
                    <div className="flex-1 min-w-0">
                      <label htmlFor={permission.id} className="text-sm font-medium text-gray-900 cursor-pointer">
                        {permission.label}
                      </label>
                      <p className="text-xs text-gray-500">{permission.description}</p>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre de usuario *
              </label>
              <div className="flex space-x-2">
                <Input
                  type="text"
                  placeholder="usuario.sistema"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="h-12 rounded-xl border-gray-200"
                />
                <Button
                  type="button"
                  variant="outline"
                  onClick={generateUsername}
                  className="h-12 px-4 rounded-xl"
                >
                  Auto
                </Button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Contraseña temporal *
              </label>
              <div className="flex space-x-2">
                <div className="relative flex-1">
                  <Input
                    type={showPassword ? "text" : "password"}
                    placeholder="Contraseña"
                    value={formData.password}
                    onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                    className="pr-10 h-12 rounded-xl border-gray-200"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword(!showPassword)}
                    className="absolute right-3 top-1/2 transform -translate-y-1/2 text-gray-400"
                  >
                    {showPassword ? <EyeOff className="w-5 h-5" /> : <Eye className="w-5 h-5" />}
                  </button>
                </div>
                <Button
                  type="button"
                  variant="outline"
                  onClick={generatePassword}
                  className="h-12 px-4 rounded-xl"
                >
                  <Key className="w-4 h-4" />
                </Button>
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Confirmar contraseña *
              </label>
              <Input
                type={showPassword ? "text" : "password"}
                placeholder="Confirmar contraseña"
                value={formData.confirmPassword}
                onChange={(e) => setFormData({ ...formData, confirmPassword: e.target.value })}
                className="h-12 rounded-xl border-gray-200"
              />
              {formData.password && formData.confirmPassword && formData.password !== formData.confirmPassword && (
                <p className="text-sm text-red-600 mt-1">Las contraseñas no coinciden</p>
              )}
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Resumen del Usuario</h3>
              <p className="text-gray-600">Revisa la información antes de crear el usuario</p>
            </div>

            <div className="space-y-4">
              <Card className="border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-base">Información Personal</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Nombre:</span>
                    <span className="font-medium">{formData.name}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Email:</span>
                    <span className="font-medium">{formData.email}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Teléfono:</span>
                    <span className="font-medium">{formData.phone}</span>
                  </div>
                </CardContent>
              </Card>

              <Card className="border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-base">Rol y Permisos</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Rol:</span>
                    <span className="font-medium">{formData.role}</span>
                  </div>
                  <div>
                    <span className="text-gray-600">Permisos ({formData.permissions.length}):</span>
                    <div className="flex flex-wrap gap-1 mt-1">
                      {formData.permissions.slice(0, 4).map((perm, index) => (
                        <span key={index} className="text-xs bg-blue-100 text-blue-800 px-2 py-1 rounded">
                          {perm.replace('_', ' ')}
                        </span>
                      ))}
                      {formData.permissions.length > 4 && (
                        <span className="text-xs bg-gray-100 text-gray-600 px-2 py-1 rounded">
                          +{formData.permissions.length - 4} más
                        </span>
                      )}
                    </div>
                  </div>
                </CardContent>
              </Card>

              <Card className="border border-gray-200">
                <CardHeader>
                  <CardTitle className="text-base">Credenciales</CardTitle>
                </CardHeader>
                <CardContent className="space-y-2">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Usuario:</span>
                    <span className="font-medium">{formData.username}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-gray-600">Contraseña:</span>
                    <span className="font-mono text-sm">{'•'.repeat(formData.password.length)}</span>
                  </div>
                </CardContent>
              </Card>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-md max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">Crear Usuario</h2>
            <p className="text-sm text-gray-600">Paso {currentStep} de 4</p>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Progress */}
        <div className="px-6 py-4">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / 4) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Content */}
        <div className="px-6 py-4 max-h-[60vh] overflow-y-auto">
          {renderStep()}
        </div>

        {/* Actions */}
        <div className="flex justify-between p-6 border-t border-gray-100">
          <Button
            variant="outline"
            onClick={() => {
              if (currentStep > 1) {
                setCurrentStep(currentStep - 1);
              } else {
                onClose();
              }
            }}
            className="rounded-xl"
          >
            {currentStep === 1 ? 'Cancelar' : 'Anterior'}
          </Button>

          <Button
            onClick={() => {
              if (currentStep < 4) {
                setCurrentStep(currentStep + 1);
              } else {
                handleSubmit();
              }
            }}
            disabled={!validateStep(currentStep) || isLoading}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            {isLoading ? 'Creando...' : currentStep === 4 ? 'Crear Usuario' : 'Siguiente'}
          </Button>
        </div>
      </div>
    </div>
  );
}