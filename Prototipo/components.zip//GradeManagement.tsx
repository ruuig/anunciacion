import { useState } from 'react';
import { 
  ChevronLeft, 
  Plus, 
  Edit, 
  Trash2, 
  GraduationCap,
  Users,
  BookOpen
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Badge } from './ui/badge';
import { CreateGradeModal } from './CreateGradeModal';

const mockGrades = [
  {
    id: 1,
    name: 'Preprimaria',
    level: 'Preprimaria',
    sections: ['A', 'B'],
    studentCount: 45,
    subjects: ['Matemáticas Básicas', 'Español', 'Inglés', 'Arte'],
    ageRange: '4-5 años',
    active: true
  },
  {
    id: 2,
    name: '1ro Primaria',
    level: 'Primaria',
    sections: ['A', 'B', 'C'],
    studentCount: 72,
    subjects: ['Matemáticas', 'Español', 'Ciencias Naturales', 'Estudios Sociales', 'Inglés'],
    ageRange: '6-7 años',
    active: true
  },
  {
    id: 3,
    name: '2do Primaria',
    level: 'Primaria',
    sections: ['A', 'B'],
    studentCount: 58,
    subjects: ['Matemáticas', 'Español', 'Ciencias Naturales', 'Estudios Sociales', 'Inglés'],
    ageRange: '7-8 años',
    active: true
  },
  {
    id: 4,
    name: '3ro Primaria',
    level: 'Primaria',
    sections: ['A', 'B', 'C'],
    studentCount: 69,
    subjects: ['Matemáticas', 'Español', 'Ciencias Naturales', 'Estudios Sociales', 'Inglés', 'Educación Física'],
    ageRange: '8-9 años',
    active: true
  },
  {
    id: 5,
    name: '1ro Secundaria',
    level: 'Secundaria',
    sections: ['A', 'B'],
    studentCount: 54,
    subjects: ['Matemáticas', 'Español', 'Ciencias Naturales', 'Estudios Sociales', 'Inglés', 'Educación Física', 'Computación'],
    ageRange: '12-13 años',
    active: true
  },
  {
    id: 6,
    name: '4to Primaria (Anterior)',
    level: 'Primaria',
    sections: ['A'],
    studentCount: 0,
    subjects: [],
    ageRange: '9-10 años',
    active: false
  }
];

const levelColors = {
  'Preprimaria': 'bg-pink-500 hover:bg-pink-600',
  'Primaria': 'bg-blue-500 hover:bg-blue-600',
  'Secundaria': 'bg-green-500 hover:bg-green-600'
};

export function GradeManagement({ user, onBack }) {
  const [grades, setGrades] = useState(mockGrades);
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingGrade, setEditingGrade] = useState(null);

  const activeGrades = grades.filter(g => g.active);
  const totalStudents = activeGrades.reduce((sum, g) => sum + g.studentCount, 0);
  const totalSections = activeGrades.reduce((sum, g) => sum + g.sections.length, 0);

  const handleCreateGrade = (newGrade) => {
    const grade = {
      ...newGrade,
      id: grades.length + 1,
      studentCount: 0,
      active: true
    };
    setGrades([...grades, grade]);
  };

  const handleEditGrade = (gradeId, updatedGrade) => {
    setGrades(grades.map(g => 
      g.id === gradeId ? { ...g, ...updatedGrade } : g
    ));
  };

  const toggleGradeStatus = (gradeId) => {
    setGrades(grades.map(g => 
      g.id === gradeId ? { ...g, active: !g.active } : g
    ));
  };

  const deleteGrade = (gradeId) => {
    if (confirm('¿Estás seguro de que quieres eliminar este grado? Esta acción no se puede deshacer.')) {
      setGrades(grades.filter(g => g.id !== gradeId));
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">Configuración de Grados</h2>
            <p className="text-gray-600">Administra grados, secciones y materias del colegio</p>
          </div>
          <Button 
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Grado
          </Button>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-blue-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-blue-800">{activeGrades.length}</p>
            <p className="text-sm text-blue-600">Grados Activos</p>
          </div>
          <div className="bg-green-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-green-800">{totalSections}</p>
            <p className="text-sm text-green-600">Secciones</p>
          </div>
          <div className="bg-purple-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-purple-800">{totalStudents}</p>
            <p className="text-sm text-purple-600">Estudiantes</p>
          </div>
        </div>
      </div>

      {/* Grades List */}
      <div className="space-y-3">
        {grades.map((grade) => (
          <Card key={grade.id} className={`shadow-sm border-0 rounded-2xl ${!grade.active ? 'opacity-60' : ''}`}>
            <CardContent className="p-6">
              <div className="flex items-start justify-between mb-4">
                <div className="flex items-center">
                  <div className={`w-12 h-12 ${levelColors[grade.level] || 'bg-gray-500'} rounded-xl flex items-center justify-center mr-4`}>
                    <GraduationCap className="w-6 h-6 text-white" />
                  </div>
                  <div>
                    <div className="flex items-center mb-1">
                      <h3 className="font-semibold text-gray-900 mr-2">{grade.name}</h3>
                      <Badge className={levelColors[grade.level] || 'bg-gray-500'}>
                        {grade.level}
                      </Badge>
                      {!grade.active && (
                        <Badge variant="secondary" className="ml-2 bg-red-100 text-red-700">
                          Inactivo
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-gray-600">{grade.ageRange}</p>
                  </div>
                </div>
                
                <div className="flex space-x-2">
                  <Button
                    size="sm"
                    variant="outline"
                    onClick={() => setEditingGrade(grade)}
                    className="rounded-lg"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant={grade.active ? 'destructive' : 'default'}
                    onClick={() => toggleGradeStatus(grade.id)}
                    className="rounded-lg"
                  >
                    {grade.active ? 'Desactivar' : 'Activar'}
                  </Button>
                </div>
              </div>

              {/* Grade Details */}
              <div className="grid grid-cols-2 gap-4 mb-4">
                <div>
                  <p className="text-sm text-gray-600 mb-1">Secciones</p>
                  <div className="flex flex-wrap gap-1">
                    {grade.sections.map((section, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        Sección {section}
                      </Badge>
                    ))}
                  </div>
                </div>
                
                <div className="text-right">
                  <div className="flex items-center justify-end mb-1">
                    <Users className="w-4 h-4 text-gray-400 mr-1" />
                    <span className="text-sm font-medium">{grade.studentCount} estudiantes</span>
                  </div>
                  <div className="flex items-center justify-end">
                    <BookOpen className="w-4 h-4 text-gray-400 mr-1" />
                    <span className="text-sm text-gray-600">{grade.subjects.length} materias</span>
                  </div>
                </div>
              </div>

              {/* Subjects */}
              {grade.subjects.length > 0 && (
                <div>
                  <p className="text-sm text-gray-600 mb-2">Materias:</p>
                  <div className="flex flex-wrap gap-1">
                    {grade.subjects.slice(0, 4).map((subject, index) => (
                      <Badge key={index} variant="outline" className="text-xs">
                        {subject}
                      </Badge>
                    ))}
                    {grade.subjects.length > 4 && (
                      <Badge variant="outline" className="text-xs">
                        +{grade.subjects.length - 4} más
                      </Badge>
                    )}
                  </div>
                </div>
              )}

              {/* Actions for inactive grades */}
              {!grade.active && grade.studentCount === 0 && (
                <div className="mt-4 pt-4 border-t border-gray-200">
                  <Button
                    size="sm"
                    variant="destructive"
                    onClick={() => deleteGrade(grade.id)}
                    className="rounded-lg"
                  >
                    <Trash2 className="w-4 h-4 mr-2" />
                    Eliminar Permanentemente
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        ))}
      </div>

      {grades.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <GraduationCap className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No hay grados configurados
          </h3>
          <p className="text-gray-600 mb-4">
            Crea el primer grado para comenzar a organizar el colegio
          </p>
          <Button 
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            <Plus className="w-4 h-4 mr-2" />
            Crear Primer Grado
          </Button>
        </div>
      )}

      {/* Create/Edit Grade Modal */}
      {(showCreateModal || editingGrade) && (
        <CreateGradeModal
          grade={editingGrade}
          onClose={() => {
            setShowCreateModal(false);
            setEditingGrade(null);
          }}
          onSuccess={(gradeData) => {
            if (editingGrade) {
              handleEditGrade(editingGrade.id, gradeData);
            } else {
              handleCreateGrade(gradeData);
            }
          }}
        />
      )}
    </div>
  );
}