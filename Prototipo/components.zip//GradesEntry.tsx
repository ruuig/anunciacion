import { useState } from 'react';
import { ChevronLeft, ChevronDown, Save, Printer, BookOpen, ClipboardList } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ActivityManagement } from './ActivityManagement';

const mockData = {
  subjects: ['Matemáticas', 'Español', 'Ciencias Naturales', 'Estudios Sociales', 'Inglés'],
  grades: ['1ro Primaria', '2do Primaria', '3ro Primaria', '4to Primaria', '5to Primaria', '6to Primaria'],
  sections: ['A', 'B', 'C'],
  periods: ['Primer Bimestre', 'Segundo Bimestre', 'Tercer Bimestre', 'Cuarto Bimestre'],
  students: [
    { id: 1, name: 'Ana María López', currentGrade: null },
    { id: 2, name: 'Carlos Roberto Mendez', currentGrade: null },
    { id: 3, name: 'María José Hernández', currentGrade: null },
    { id: 4, name: 'Diego Alexander Ruiz', currentGrade: null },
    { id: 5, name: 'Sofía Isabella García', currentGrade: null },
    { id: 6, name: 'Luis Fernando Morales', currentGrade: null },
    { id: 7, name: 'Carmen Elena Rodríguez', currentGrade: null },
    { id: 8, name: 'José Antonio Paz', currentGrade: null }
  ]
};

export function GradesEntry({ user, onBack }) {
  const [activeTab, setActiveTab] = useState('grades');
  const [selectedSubject, setSelectedSubject] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('');
  const [selectedSection, setSelectedSection] = useState('');
  const [selectedPeriod, setSelectedPeriod] = useState('');
  const [students, setStudents] = useState(mockData.students);
  const [isSaving, setIsSaving] = useState(false);

  const isTeacher = user?.role === 'Docente';
  const isSecretary = user?.role === 'Secretaria';
  const canPrintReports = user?.permissions?.includes('print_reports');

  // Filter grades based on user role
  const availableGrades = isTeacher && user?.assignedGrades 
    ? mockData.grades.filter(grade => user.assignedGrades.includes(grade))
    : mockData.grades;

  const updateGrade = (studentId, grade) => {
    const numericGrade = parseFloat(grade);
    if (isNaN(numericGrade) || numericGrade < 0 || numericGrade > 100) return;

    setStudents(prev => prev.map(student => 
      student.id === studentId 
        ? { ...student, currentGrade: numericGrade }
        : student
    ));
  };

  const getGradeColor = (grade) => {
    if (grade === null || grade === undefined) return 'border-gray-300';
    if (grade >= 70) return 'border-green-500 bg-green-50';
    return 'border-red-500 bg-red-50';
  };

  const canShowStudents = selectedSubject && selectedGrade && selectedSection && selectedPeriod;

  const handleSave = async () => {
    setIsSaving(true);
    // Simulate save delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    setIsSaving(false);
    
    // Show success message (you could implement a toast here)
    alert('Calificaciones guardadas exitosamente');
  };

  const handlePrintReports = () => {
    if (!canShowStudents) {
      alert('Selecciona todos los campos para imprimir las boletas');
      return;
    }
    alert(`Generando boletas para ${selectedGrade} - Sección ${selectedSection} - ${selectedPeriod}`);
  };

  const renderGradesContent = () => (
    <>
      {/* Selection Form */}
      <Card className="shadow-sm border-0 rounded-2xl">
        <CardHeader>
          <CardTitle className="text-lg">Seleccionar Clase</CardTitle>
          {isTeacher && (
            <p className="text-sm text-gray-600">
              Mostrando solo los grados asignados a ti: {user?.assignedGrades?.join(', ')}
            </p>
          )}
        </CardHeader>
        <CardContent className="space-y-4">
          {/* Subject Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Materia
            </label>
            <Select value={selectedSubject} onValueChange={setSelectedSubject}>
              <SelectTrigger className="h-12 rounded-xl border-gray-200">
                <SelectValue placeholder="Selecciona una materia" />
              </SelectTrigger>
              <SelectContent>
                {mockData.subjects.map((subject) => (
                  <SelectItem key={subject} value={subject}>
                    {subject}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Grade and Section Selection */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Grado
              </label>
              <Select value={selectedGrade} onValueChange={setSelectedGrade}>
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Grado" />
                </SelectTrigger>
                <SelectContent>
                  {availableGrades.map((grade) => (
                    <SelectItem key={grade} value={grade}>
                      {grade}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sección
              </label>
              <Select value={selectedSection} onValueChange={setSelectedSection}>
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Sección" />
                </SelectTrigger>
                <SelectContent>
                  {mockData.sections.map((section) => (
                    <SelectItem key={section} value={section}>
                      {section}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>

          {/* Period Selection */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Periodo
            </label>
            <Select value={selectedPeriod} onValueChange={setSelectedPeriod}>
              <SelectTrigger className="h-12 rounded-xl border-gray-200">
                <SelectValue placeholder="Selecciona el periodo" />
              </SelectTrigger>
              <SelectContent>
                {mockData.periods.map((period) => (
                  <SelectItem key={period} value={period}>
                    {period}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </CardContent>
      </Card>

      {/* Students List */}
      {canShowStudents && (
        <Card className="shadow-sm border-0 rounded-2xl">
          <CardHeader className="flex flex-row items-center justify-between">
            <CardTitle className="text-lg">Lista de Estudiantes</CardTitle>
            <Button 
              onClick={handleSave}
              disabled={isSaving}
              className="bg-blue-500 hover:bg-blue-600 rounded-xl"
            >
              <Save className="w-4 h-4 mr-2" />
              {isSaving ? 'Guardando...' : 'Guardar'}
            </Button>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {students.map((student) => (
                <div key={student.id} className="flex items-center justify-between py-3 border-b border-gray-100 last:border-b-0">
                  <div className="flex-1">
                    <p className="font-medium text-gray-900">{student.name}</p>
                  </div>
                  <div className="w-20">
                    <Input
                      type="number"
                      min="0"
                      max="100"
                      placeholder="0-100"
                      value={student.currentGrade || ''}
                      onChange={(e) => updateGrade(student.id, e.target.value)}
                      className={`h-10 text-center rounded-lg ${getGradeColor(student.currentGrade)}`}
                    />
                  </div>
                </div>
              ))}
            </div>

            {/* Summary */}
            <div className="mt-6 pt-4 border-t border-gray-200">
              <div className="grid grid-cols-3 gap-4 text-sm">
                <div className="text-center">
                  <p className="text-gray-600">Aprobados</p>
                  <p className="font-semibold text-green-600">
                    {students.filter(s => s.currentGrade >= 70).length}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-gray-600">Reprobados</p>
                  <p className="font-semibold text-red-600">
                    {students.filter(s => s.currentGrade < 70 && s.currentGrade !== null).length}
                  </p>
                </div>
                <div className="text-center">
                  <p className="text-gray-600">Pendientes</p>
                  <p className="font-semibold text-gray-600">
                    {students.filter(s => s.currentGrade === null).length}
                  </p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      {!canShowStudents && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <ChevronDown className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Selecciona todos los campos
          </h3>
          <p className="text-gray-600">
            Completa la información para ver la lista de estudiantes
          </p>
        </div>
      )}
    </>
  );

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <button onClick={onBack} className="mr-3 p-1">
              <ChevronLeft className="w-6 h-6 text-blue-500" />
            </button>
            <h1 className="text-xl font-semibold text-gray-900">
              {isTeacher ? 'Gestión Académica' : 'Calificaciones'}
            </h1>
          </div>
          {canPrintReports && (
            <Button 
              onClick={handlePrintReports}
              disabled={!canShowStudents}
              variant="outline"
              className="rounded-xl"
            >
              <Printer className="w-4 h-4 mr-2" />
              Imprimir Boletas
            </Button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {isTeacher ? (
          <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
            <TabsList className="grid w-full grid-cols-2 bg-gray-100 rounded-xl">
              <TabsTrigger value="grades" className="rounded-lg flex items-center">
                <BookOpen className="w-4 h-4 mr-2" />
                Calificaciones
              </TabsTrigger>
              <TabsTrigger value="activities" className="rounded-lg flex items-center">
                <ClipboardList className="w-4 h-4 mr-2" />
                Actividades
              </TabsTrigger>
            </TabsList>

            <TabsContent value="grades" className="mt-4">
              {renderGradesContent()}
            </TabsContent>

            <TabsContent value="activities" className="mt-4">
              <ActivityManagement 
                user={user}
                availableGrades={availableGrades}
              />
            </TabsContent>
          </Tabs>
        ) : (
          renderGradesContent()
        )}
      </div>

      {/* Bottom padding */}
      <div className="h-6"></div>
    </div>
  );
}