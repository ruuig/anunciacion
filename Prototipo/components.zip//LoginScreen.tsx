import { useState } from 'react';
import { Eye, EyeOff, User, Lock } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { SCHOOL_LOGO, ANIMATED_AVATARS } from '../utils/avatars';
import { ImageWithFallback } from './figma/ImageWithFallback';

export function LoginScreen({ onLogin }) {
  const [formData, setFormData] = useState({ username: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    // Simulate login delay
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    // Mock authentication logic based on username
    let userData;
    
    if (formData.username.toLowerCase().includes('admin') || formData.username.toLowerCase().includes('director')) {
      userData = {
        name: 'Roberto Díaz',
        role: 'Director',
        permissions: ['view_all', 'edit_all', 'delete_all', 'manage_users', 'manage_grades', 'manage_students'],
        avatar: ANIMATED_AVATARS.teachers[0]
      };
    } else if (formData.username.toLowerCase().includes('secretaria')) {
      userData = {
        name: 'Ana Rodríguez',
        role: 'Secretaria',
        permissions: ['view_students', 'edit_students', 'manage_payments', 'view_reports', 'manage_grades', 'print_reports'],
        avatar: ANIMATED_AVATARS.teachers[1]
      };
    } else {
      userData = {
        name: 'María González',
        role: 'Docente',
        permissions: ['view_students', 'manage_grades', 'view_attendance'],
        assignedGrades: ['3ro Primaria', '4to Primaria'], // Grados asignados al docente
        avatar: ANIMATED_AVATARS.teachers[2]
      };
    }
    
    onLogin(userData);
    setIsLoading(false);
  };

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-50 to-white flex flex-col items-center justify-center p-4">
      {/* Logo */}
      <div className="mb-16 text-center">
        <div className="w-28 h-28 mx-auto mb-4 rounded-full overflow-hidden bg-white shadow-lg flex items-center justify-center border-4 border-blue-100">
          <ImageWithFallback
            src={SCHOOL_LOGO}
            alt="Logo del colegio"
            className="w-24 h-24 object-contain"
          />
        </div>
        <h1 className="text-xl font-semibold text-gray-900 mb-2">
          Nuestra Señora de la Anunciación
        </h1>
        <p className="text-gray-600 text-sm">Sistema de Gestión Escolar</p>
      </div>

      {/* Login Form */}
      <div className="w-full max-w-sm">
        <h2 className="text-2xl font-bold text-gray-900 mb-8 text-center">
          Iniciar Sesión
        </h2>
        
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Username Field */}
          <div className="relative">
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400">
              <User size={20} />
            </div>
            <Input
              type="text"
              placeholder="Usuario"
              value={formData.username}
              onChange={(e) => setFormData({ ...formData, username: e.target.value })}
              className="h-12 pl-12 bg-white border border-gray-200 rounded-xl text-base"
              required
            />
          </div>

          {/* Password Field */}
          <div className="relative">
            <div className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400">
              <Lock size={20} />
            </div>
            <Input
              type={showPassword ? "text" : "password"}
              placeholder="Contraseña"
              value={formData.password}
              onChange={(e) => setFormData({ ...formData, password: e.target.value })}
              className="h-12 pl-12 pr-12 bg-white border border-gray-200 rounded-xl text-base"
              required
            />
            <button
              type="button"
              onClick={() => setShowPassword(!showPassword)}
              className="absolute right-4 top-1/2 transform -translate-y-1/2 text-gray-400 hover:text-gray-600"
            >
              {showPassword ? <EyeOff size={20} /> : <Eye size={20} />}
            </button>
          </div>

          {/* Login Button */}
          <Button
            type="submit"
            disabled={isLoading}
            className="w-full h-12 bg-blue-500 hover:bg-blue-600 text-white rounded-xl font-semibold text-base mt-6"
          >
            {isLoading ? 'Iniciando sesión...' : 'Iniciar Sesión'}
          </Button>
        </form>

        {/* Forgot Password Link */}
        <div className="text-center mt-6">
          <button className="text-blue-500 text-base font-medium">
            ¿Olvidaste tu contraseña?
          </button>
        </div>
      </div>
    </div>
  );
}