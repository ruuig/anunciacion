import { useState } from 'react';
import { 
  BookOpen, 
  DollarSign, 
  BarChart3, 
  Users, 
  Calendar, 
  Settings,
  Bell,
  Search,
  FileText,
  User
} from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { StudentList } from './StudentList';
import { GradesEntry } from './GradesEntry';
import { PaymentManagement } from './PaymentManagement';
import { AttendanceControl } from './AttendanceControl';
import { AdministrationModule } from './AdministrationModule';
import { SCHOOL_LOGO } from '../utils/avatars';

const getModulesForUser = (user) => {
  const allModules = [
    {
      id: 'grades',
      title: 'Calificaciones',
      description: 'Ingresa y consulta notas',
      icon: BookOpen,
      color: 'bg-blue-500',
      permission: 'manage_grades'
    },
    {
      id: 'payments',
      title: 'Pagos',
      description: 'Gestiona pagos de estudiantes',
      icon: DollarSign,
      color: 'bg-green-500',
      permission: 'manage_payments'
    },
    {
      id: 'reports',
      title: 'Reportes',
      description: 'Genera reportes académicos',
      icon: BarChart3,
      color: 'bg-orange-500',
      permission: 'view_reports'
    },
    {
      id: 'students',
      title: 'Estudiantes',
      description: 'Lista de estudiantes',
      icon: Users,
      color: 'bg-purple-500',
      permission: 'view_students'
    },
    {
      id: 'attendance',
      title: 'Asistencia',
      description: 'Control de entrada/salida',
      icon: Calendar,
      color: 'bg-pink-500',
      permission: 'view_attendance'
    },
    {
      id: 'administration',
      title: 'Administración',
      description: 'Gestión de usuarios y sistema',
      icon: Settings,
      color: 'bg-gray-500',
      permission: 'manage_users'
    }
  ];

  // Filter modules based on user permissions
  return allModules.map(module => ({
    ...module,
    enabled: user.permissions?.includes(module.permission) || user.permissions?.includes('view_all')
  }));
};

export function MainDashboard({ user, onLogout }) {
  const [activeModule, setActiveModule] = useState('dashboard');
  const [notificationCount] = useState(3);
  const modules = getModulesForUser(user);

  const renderActiveModule = () => {
    switch (activeModule) {
      case 'students':
        return <StudentList user={user} onBack={() => setActiveModule('dashboard')} />;
      case 'grades':
        return <GradesEntry user={user} onBack={() => setActiveModule('dashboard')} />;
      case 'payments':
        return <PaymentManagement user={user} onBack={() => setActiveModule('dashboard')} />;
      case 'attendance':
        return <AttendanceControl user={user} onBack={() => setActiveModule('dashboard')} />;
      case 'administration':
        return <AdministrationModule user={user} onBack={() => setActiveModule('dashboard')} />;
      default:
        return (
          <div className="space-y-6">
            {/* Greeting */}
            <div className="bg-white rounded-2xl p-6 shadow-sm">
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">
                Hola, {user?.name || 'Usuario'}
              </h2>
              <p className="text-gray-600">
                Bienvenido al sistema de gestión escolar
              </p>
            </div>

            {/* Modules Grid */}
            <div className="grid grid-cols-2 gap-4">
              {modules.map((module) => {
                const IconComponent = module.icon;
                return (
                  <button
                    key={module.id}
                    onClick={() => module.enabled && setActiveModule(module.id)}
                    disabled={!module.enabled}
                    className={`
                      bg-white rounded-2xl p-6 shadow-sm text-left transition-all duration-200
                      ${module.enabled 
                        ? 'hover:shadow-md active:scale-95' 
                        : 'opacity-40 cursor-not-allowed'
                      }
                    `}
                  >
                    <div className={`w-12 h-12 ${module.color} rounded-xl flex items-center justify-center mb-4`}>
                      <IconComponent className="w-6 h-6 text-white" />
                    </div>
                    <h3 className="font-semibold text-gray-900 mb-1">
                      {module.title}
                    </h3>
                    <p className="text-sm text-gray-600">
                      {module.description}
                    </p>
                    {!module.enabled && (
                      <div className="mt-2">
                        <Badge variant="secondary" className="text-xs">
                          Próximamente
                        </Badge>
                      </div>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        );
    }
  };

  if (activeModule !== 'dashboard') {
    return renderActiveModule();
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="flex items-center justify-between p-4">
          <h1 className="text-xl font-semibold text-gray-900">Inicio</h1>
          <div className="flex items-center space-x-3">
            <button className="relative p-2">
              <Bell className="w-6 h-6 text-gray-600" />
              {notificationCount > 0 && (
                <Badge className="absolute -top-1 -right-1 w-5 h-5 flex items-center justify-center p-0 bg-red-500 text-white text-xs">
                  {notificationCount}
                </Badge>
              )}
            </button>
            <button className="w-8 h-8 rounded-full overflow-hidden bg-gray-200">
              <img
                src={user?.avatar}
                alt={user?.name}
                className="w-full h-full object-cover"
              />
            </button>
          </div>
        </div>
      </div>

      {/* Content */}
      <div className="p-4">
        {renderActiveModule()}
      </div>

      {/* Tab Bar */}
      <div className="fixed bottom-0 left-0 right-0 bg-white border-t border-gray-100">
        <div className="flex items-center justify-around py-2">
          <button 
            className="flex flex-col items-center p-2 text-blue-500"
            onClick={() => setActiveModule('dashboard')}
          >
            <div className="w-6 h-6 mb-1">
              <div className="w-full h-full bg-blue-500 rounded-sm"></div>
            </div>
            <span className="text-xs">Inicio</span>
          </button>
          
          <button className="flex flex-col items-center p-2 text-gray-400">
            <Search className="w-6 h-6 mb-1" />
            <span className="text-xs">Búsqueda</span>
          </button>
          
          <button className="flex flex-col items-center p-2 text-gray-400">
            <FileText className="w-6 h-6 mb-1" />
            <span className="text-xs">Reportes</span>
          </button>
          
          <button 
            className="flex flex-col items-center p-2 text-gray-400"
            onClick={onLogout}
          >
            <User className="w-6 h-6 mb-1" />
            <span className="text-xs">Perfil</span>
          </button>
        </div>
      </div>

      {/* Bottom padding to account for tab bar */}
      <div className="h-20"></div>
    </div>
  );
}