import { useState } from 'react';
import { X, User, DollarSign, Calendar, FileText, CreditCard, Search } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { getAvatarByIndex } from '../utils/avatars';

// Mock data de estudiantes
const mockStudents = [
  {
    id: 1,
    name: 'Ana María López',
    grade: '5to Primaria',
    section: 'A',
    avatar: getAvatarByIndex(0, 'students'),
    balance: 800,
    lastPayment: '2024-01-15'
  },
  {
    id: 2,
    name: 'Carlos Roberto Mendez',
    grade: '3ro Secundaria',
    section: 'B',
    avatar: getAvatarByIndex(1, 'students'),
    balance: 1200,
    lastPayment: '2023-12-10'
  },
  {
    id: 3,
    name: 'María José Hernández',
    grade: '2do Primaria',
    section: 'A',
    avatar: getAvatarByIndex(2, 'students'),
    balance: 0,
    lastPayment: '2024-01-20'
  },
  {
    id: 4,
    name: 'Diego Alexander Ruiz',
    grade: '1ro Secundaria',
    section: 'C',
    avatar: getAvatarByIndex(3, 'students'),
    balance: 600,
    lastPayment: '2023-11-25'
  }
];

const paymentConcepts = [
  'Mensualidad',
  'Inscripción',
  'Matrícula',
  'Actividades Extracurriculares',
  'Material Didáctico',
  'Uniforme',
  'Alimentación',
  'Transporte',
  'Otro'
];

const paymentMethods = [
  'Efectivo',
  'Transferencia Bancaria',
  'Depósito Bancario',
  'Tarjeta de Crédito',
  'Tarjeta de Débito',
  'Cheque'
];

export function ManualPaymentModal({ onClose, onSuccess }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [searchStudent, setSearchStudent] = useState('');
  
  const [formData, setFormData] = useState({
    studentId: '',
    amount: '',
    concept: '',
    paymentMethod: '',
    referenceNumber: '',
    date: new Date().toISOString().split('T')[0],
    notes: ''
  });

  const [selectedStudent, setSelectedStudent] = useState(null);

  // Filtrar estudiantes por búsqueda
  const filteredStudents = mockStudents.filter(student =>
    student.name.toLowerCase().includes(searchStudent.toLowerCase()) ||
    student.grade.toLowerCase().includes(searchStudent.toLowerCase())
  );

  const handleStudentSelect = (student) => {
    setSelectedStudent(student);
    setFormData({ ...formData, studentId: student.id });
  };

  const validateStep = (step) => {
    switch (step) {
      case 1:
        return selectedStudent !== null;
      case 2:
        return formData.amount && formData.concept && formData.paymentMethod && formData.date;
      default:
        return true;
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Here you would send the payment data to your backend
    console.log('Payment data:', { ...formData, student: selectedStudent });
    
    setIsLoading(false);
    onSuccess();
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Seleccionar Estudiante
              </h3>
              <p className="text-gray-600">
                Busca y selecciona el estudiante para registrar el pago
              </p>
            </div>

            {/* Search */}
            <div className="relative">
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
              <Input
                type="text"
                placeholder="Buscar por nombre o grado..."
                value={searchStudent}
                onChange={(e) => setSearchStudent(e.target.value)}
                className="pl-10 h-12 rounded-xl border-gray-200"
              />
            </div>

            {/* Students List */}
            <div className="max-h-80 overflow-y-auto space-y-2">
              {filteredStudents.map((student) => (
                <button
                  key={student.id}
                  onClick={() => handleStudentSelect(student)}
                  className={`w-full p-4 rounded-xl border text-left transition-all ${
                    selectedStudent?.id === student.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 mr-3">
                      <img
                        src={student.avatar}
                        alt={student.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center justify-between mb-1">
                        <h4 className="font-medium text-gray-900">{student.name}</h4>
                        <Badge 
                          className={`text-xs ${
                            student.balance > 0 
                              ? 'bg-red-500 hover:bg-red-600' 
                              : 'bg-green-500 hover:bg-green-600'
                          }`}
                        >
                          {student.balance > 0 ? 'Mora' : 'Al día'}
                        </Badge>
                      </div>
                      <p className="text-sm text-gray-600">
                        {student.grade} - Sección {student.section}
                      </p>
                      <div className="flex items-center justify-between mt-1 text-xs text-gray-500">
                        <span>Último pago: {student.lastPayment}</span>
                        {student.balance > 0 && (
                          <span className="text-red-600 font-medium">
                            Debe: Q {student.balance.toLocaleString()}
                          </span>
                        )}
                      </div>
                    </div>
                  </div>
                </button>
              ))}
            </div>

            {filteredStudents.length === 0 && (
              <div className="text-center py-8">
                <User className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <p className="text-gray-600">No se encontraron estudiantes</p>
              </div>
            )}
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <DollarSign className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Detalles del Pago
              </h3>
              <p className="text-gray-600">
                Ingresa la información del pago de {selectedStudent?.name}
              </p>
            </div>

            {/* Student Info */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4 mb-6">
              <div className="flex items-center">
                <div className="w-10 h-10 rounded-full overflow-hidden bg-gray-200 mr-3">
                  <img
                    src={selectedStudent?.avatar}
                    alt={selectedStudent?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="font-medium text-blue-900">{selectedStudent?.name}</p>
                  <p className="text-sm text-blue-700">
                    {selectedStudent?.grade} - Sección {selectedStudent?.section}
                  </p>
                </div>
              </div>
            </div>

            {/* Payment Form */}
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Monto *
                </label>
                <div className="relative">
                  <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                    Q
                  </span>
                  <Input
                    type="number"
                    step="0.01"
                    placeholder="0.00"
                    value={formData.amount}
                    onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                    className="pl-8 h-12 rounded-xl border-gray-200"
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fecha de pago *
                </label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="h-12 rounded-xl border-gray-200"
                />
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Concepto *
              </label>
              <Select 
                value={formData.concept} 
                onValueChange={(value) => setFormData({ ...formData, concept: value })}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Selecciona el concepto" />
                </SelectTrigger>
                <SelectContent>
                  {paymentConcepts.map((concept) => (
                    <SelectItem key={concept} value={concept}>
                      {concept}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Método de pago *
              </label>
              <Select 
                value={formData.paymentMethod} 
                onValueChange={(value) => setFormData({ ...formData, paymentMethod: value })}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Selecciona el método" />
                </SelectTrigger>
                <SelectContent>
                  {paymentMethods.map((method) => (
                    <SelectItem key={method} value={method}>
                      {method}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Número de referencia (opcional)
              </label>
              <Input
                type="text"
                placeholder="Número de transacción, cheque, etc."
                value={formData.referenceNumber}
                onChange={(e) => setFormData({ ...formData, referenceNumber: e.target.value })}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Notas adicionales (opcional)
              </label>
              <Textarea
                placeholder="Información adicional sobre el pago..."
                value={formData.notes}
                onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                className="min-h-[80px] rounded-xl border-gray-200"
              />
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CreditCard className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Confirmar Pago
              </h3>
              <p className="text-gray-600">
                Revisa los detalles antes de registrar el pago
              </p>
            </div>

            {/* Payment Summary */}
            <div className="bg-gray-50 rounded-xl p-6 space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Estudiante:</span>
                <span className="font-medium">{selectedStudent?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Grado:</span>
                <span className="font-medium">{selectedStudent?.grade} - Sección {selectedStudent?.section}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Monto:</span>
                <span className="font-medium text-green-600">Q {parseFloat(formData.amount || 0).toLocaleString()}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Concepto:</span>
                <span className="font-medium">{formData.concept}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Método:</span>
                <span className="font-medium">{formData.paymentMethod}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Fecha:</span>
                <span className="font-medium">{formData.date}</span>
              </div>
              {formData.referenceNumber && (
                <div className="flex justify-between">
                  <span className="text-gray-600">Referencia:</span>
                  <span className="font-medium">{formData.referenceNumber}</span>
                </div>
              )}
              {formData.notes && (
                <div>
                  <span className="text-gray-600">Notas:</span>
                  <p className="text-sm text-gray-800 mt-1">{formData.notes}</p>
                </div>
              )}
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <div className="flex items-center">
                <FileText className="w-5 h-5 text-yellow-600 mr-2" />
                <div>
                  <p className="font-medium text-yellow-900">Importante</p>
                  <p className="text-sm text-yellow-700">
                    Este pago será registrado inmediatamente y se actualizará el estado del estudiante.
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              Registrar Pago Manual
            </h2>
            <p className="text-sm text-gray-600">Paso {currentStep} de 3</p>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Progress */}
        <div className="px-6 py-4">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-blue-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / 3) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Content */}
        <div className="px-6 py-4 max-h-[60vh] overflow-y-auto">
          {renderStep()}
        </div>

        {/* Actions */}
        <div className="flex justify-between p-6 border-t border-gray-100">
          <Button
            variant="outline"
            onClick={() => {
              if (currentStep > 1) {
                setCurrentStep(currentStep - 1);
              } else {
                onClose();
              }
            }}
            className="rounded-xl"
          >
            {currentStep === 1 ? 'Cancelar' : 'Anterior'}
          </Button>

          <Button
            onClick={() => {
              if (currentStep < 3) {
                setCurrentStep(currentStep + 1);
              } else {
                handleSubmit();
              }
            }}
            disabled={!validateStep(currentStep) || isLoading}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            {isLoading ? 'Registrando...' : currentStep === 3 ? 'Registrar Pago' : 'Siguiente'}
          </Button>
        </div>
      </div>
    </div>
  );
}