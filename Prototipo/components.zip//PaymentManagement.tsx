import { useState } from 'react';
import { 
  ChevronLeft, 
  Upload, 
  FileText, 
  DollarSign, 
  Calendar,
  User,
  CreditCard,
  Receipt
} from 'lucide-react';
import { Button } from './ui/button';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { ManualPaymentModal } from './ManualPaymentModal';
import { PaymentUploadModal } from './PaymentUploadModal';

export function PaymentManagement({ user, onBack }) {
  const [showManualModal, setShowManualModal] = useState(false);
  const [showUploadModal, setShowUploadModal] = useState(false);

  const isSecretary = user?.role === 'Secretaria';
  
  // Solo las secretarias pueden acceder a este módulo
  if (!isSecretary) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <DollarSign className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            Acceso Restringido
          </h3>
          <p className="text-gray-600 mb-4">
            Solo el personal de secretaría puede acceder a la gestión de pagos
          </p>
          <Button onClick={onBack} variant="outline" className="rounded-xl">
            Volver al Dashboard
          </Button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="flex items-center p-4">
          <button onClick={onBack} className="mr-3 p-1">
            <ChevronLeft className="w-6 h-6 text-blue-500" />
          </button>
          <h1 className="text-xl font-semibold text-gray-900">Registrar Pagos</h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-6">
        {/* Header */}
        <div className="bg-white rounded-2xl p-6 shadow-sm">
          <div className="flex items-center mb-4">
            <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center mr-4">
              <DollarSign className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">Gestión de Pagos</h2>
              <p className="text-gray-600">Registra pagos de estudiantes de forma manual o mediante documentos</p>
            </div>
          </div>
          
          <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
            <div className="flex items-center">
              <Receipt className="w-5 h-5 text-blue-600 mr-2" />
              <div>
                <p className="font-medium text-blue-900">Información del usuario</p>
                <p className="text-sm text-blue-700">
                  {user.name} - {user.role}
                </p>
              </div>
            </div>
          </div>
        </div>

        {/* Payment Options */}
        <div className="grid grid-cols-1 gap-4">
          {/* Manual Payment Entry */}
          <Card className="shadow-sm border-0 rounded-2xl hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center">
                  <div className="w-16 h-16 bg-blue-100 rounded-xl flex items-center justify-center mr-4">
                    <CreditCard className="w-8 h-8 text-blue-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Registrar Pago Manual
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Ingresa los datos del pago directamente en el sistema. Ideal para pagos en efectivo o transferencias directas.
                    </p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <div className="flex items-center">
                        <User className="w-4 h-4 mr-1" />
                        Selección de estudiante
                      </div>
                      <div className="flex items-center">
                        <DollarSign className="w-4 h-4 mr-1" />
                        Monto y concepto
                      </div>
                      <div className="flex items-center">
                        <Calendar className="w-4 h-4 mr-1" />
                        Fecha de pago
                      </div>
                    </div>
                  </div>
                </div>
                
                <Button 
                  onClick={() => setShowManualModal(true)}
                  className="bg-blue-500 hover:bg-blue-600 rounded-xl"
                  size="lg"
                >
                  <CreditCard className="w-5 h-5 mr-2" />
                  Registrar Pago
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Document Upload */}
          <Card className="shadow-sm border-0 rounded-2xl hover:shadow-md transition-shadow">
            <CardContent className="p-6">
              <div className="flex items-start justify-between">
                <div className="flex items-center">
                  <div className="w-16 h-16 bg-green-100 rounded-xl flex items-center justify-center mr-4">
                    <Upload className="w-8 h-8 text-green-600" />
                  </div>
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 mb-2">
                      Subir Comprobante de Pago
                    </h3>
                    <p className="text-gray-600 mb-4">
                      Sube documentos PDF de comprobantes de pago, vouchers bancarios o recibos oficiales.
                    </p>
                    <div className="flex items-center space-x-4 text-sm text-gray-500">
                      <div className="flex items-center">
                        <FileText className="w-4 h-4 mr-1" />
                        Archivos PDF únicamente
                      </div>
                      <div className="flex items-center">
                        <Upload className="w-4 h-4 mr-1" />
                        Máximo 10MB por archivo
                      </div>
                      <div className="flex items-center">
                        <Receipt className="w-4 h-4 mr-1" />
                        Procesamiento automático
                      </div>
                    </div>
                  </div>
                </div>
                
                <Button 
                  onClick={() => setShowUploadModal(true)}
                  variant="outline"
                  className="border-green-200 text-green-700 hover:bg-green-50 rounded-xl"
                  size="lg"
                >
                  <Upload className="w-5 h-5 mr-2" />
                  Subir Documento
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Instructions */}
        <Card className="shadow-sm border-0 rounded-2xl bg-gray-50">
          <CardContent className="p-6">
            <h3 className="font-semibold text-gray-900 mb-3">
              Instrucciones Importantes
            </h3>
            <div className="space-y-2 text-sm text-gray-600">
              <div className="flex items-start">
                <div className="w-2 h-2 bg-blue-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <p>
                  <strong>Registro Manual:</strong> Usa esta opción para pagos en efectivo, transferencias bancarias sin comprobante digital, o cuando necesites ingresar detalles específicos del pago.
                </p>
              </div>
              <div className="flex items-start">
                <div className="w-2 h-2 bg-green-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <p>
                  <strong>Subir Documento:</strong> Ideal para vouchers bancarios, recibos de depósito, o cualquier comprobante oficial en formato PDF.
                </p>
              </div>
              <div className="flex items-start">
                <div className="w-2 h-2 bg-orange-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <p>
                  <strong>Verificación:</strong> Todos los pagos registrados requieren verificación antes de ser aplicados al estado del estudiante.
                </p>
              </div>
              <div className="flex items-start">
                <div className="w-2 h-2 bg-purple-500 rounded-full mt-2 mr-3 flex-shrink-0"></div>
                <p>
                  <strong>Consulta de Estados:</strong> Para ver el estado de pagos de los estudiantes, dirígete al módulo de "Estudiantes".
                </p>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Quick Stats */}
        <div className="grid grid-cols-2 gap-4">
          <Card className="shadow-sm border-0 rounded-2xl bg-blue-50">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-blue-500 rounded-xl flex items-center justify-center mx-auto mb-2">
                <FileText className="w-6 h-6 text-white" />
              </div>
              <p className="text-2xl font-bold text-blue-800">0</p>
              <p className="text-sm text-blue-600">Pagos Hoy</p>
            </CardContent>
          </Card>

          <Card className="shadow-sm border-0 rounded-2xl bg-green-50">
            <CardContent className="p-4 text-center">
              <div className="w-12 h-12 bg-green-500 rounded-xl flex items-center justify-center mx-auto mb-2">
                <DollarSign className="w-6 h-6 text-white" />
              </div>
              <p className="text-2xl font-bold text-green-800">Q 0</p>
              <p className="text-sm text-green-600">Monto Hoy</p>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Modals */}
      {showManualModal && (
        <ManualPaymentModal
          onClose={() => setShowManualModal(false)}
          onSuccess={() => {
            setShowManualModal(false);
            // Aquí se actualizarían las estadísticas
          }}
        />
      )}

      {showUploadModal && (
        <PaymentUploadModal
          onClose={() => setShowUploadModal(false)}
          onSuccess={() => {
            setShowUploadModal(false);
            // Aquí se actualizarían las estadísticas
          }}
        />
      )}

      {/* Bottom padding */}
      <div className="h-6"></div>
    </div>
  );
}