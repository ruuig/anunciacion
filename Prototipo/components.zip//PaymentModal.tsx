import { useState } from 'react';
import { X, Upload, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

const paymentConcepts = [
  'Matrícula',
  'Colegiatura Mensual',
  'Materiales Didácticos',
  'Uniforme',
  'Transporte',
  'Alimentación',
  'Actividades Extracurriculares',
  'Otros'
];

const paymentMethods = [
  'Efectivo',
  'Transferencia Bancaria',
  'Tarjeta de Crédito',
  'Tarjeta de Débito',
  'Cheque'
];

export function PaymentModal({ student, onClose, onSuccess }) {
  const [formData, setFormData] = useState({
    amount: '',
    concept: '',
    method: '',
    date: new Date().toISOString().split('T')[0],
    notes: '',
    receipt: null
  });
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));

    // Show success message
    alert(`Pago de Q${formData.amount} registrado exitosamente para ${student.studentName}`);
    
    setIsLoading(false);
    onSuccess();
  };

  const handleFileUpload = (e) => {
    const file = e.target.files[0];
    if (file) {
      setFormData({ ...formData, receipt: file });
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-end justify-center z-50">
      <div className="bg-white rounded-t-3xl w-full max-w-md max-h-[90vh] overflow-y-auto">
        {/* Handle Bar */}
        <div className="flex justify-center py-2">
          <div className="w-12 h-1 bg-gray-300 rounded-full"></div>
        </div>

        {/* Header */}
        <div className="flex items-center justify-between p-4 border-b border-gray-100">
          <h2 className="text-xl font-semibold text-gray-900">Registrar Pago</h2>
          <button 
            onClick={onClose}
            className="w-8 h-8 bg-gray-100 rounded-full flex items-center justify-center"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Student Info */}
        <div className="p-4 bg-gray-50 border-b border-gray-100">
          <div className="flex items-center">
            <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 mr-3">
              <img
                src={student.avatar}
                alt={student.studentName}
                className="w-full h-full object-cover"
              />
            </div>
            <div>
              <h3 className="font-semibold text-gray-900">{student.studentName}</h3>
              <p className="text-sm text-gray-600">
                {student.grade} - Sección {student.section}
              </p>
              <p className="text-sm text-red-600 font-medium">
                Saldo pendiente: Q {student.pendingAmount?.toLocaleString() || '0'}
              </p>
            </div>
          </div>
        </div>

        {/* Form */}
        <form onSubmit={handleSubmit} className="p-4 space-y-4">
          {/* Amount */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Monto
            </label>
            <div className="relative">
              <div className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                Q
              </div>
              <Input
                type="number"
                step="0.01"
                min="0"
                placeholder="0.00"
                value={formData.amount}
                onChange={(e) => setFormData({ ...formData, amount: e.target.value })}
                className="pl-8 h-12 rounded-xl border-gray-200"
                required
              />
            </div>
          </div>

          {/* Concept */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Concepto
            </label>
            <Select value={formData.concept} onValueChange={(value) => setFormData({ ...formData, concept: value })}>
              <SelectTrigger className="h-12 rounded-xl border-gray-200">
                <SelectValue placeholder="Selecciona el concepto" />
              </SelectTrigger>
              <SelectContent>
                {paymentConcepts.map((concept) => (
                  <SelectItem key={concept} value={concept}>
                    {concept}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Payment Method */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Método de pago
            </label>
            <Select value={formData.method} onValueChange={(value) => setFormData({ ...formData, method: value })}>
              <SelectTrigger className="h-12 rounded-xl border-gray-200">
                <SelectValue placeholder="Selecciona el método" />
              </SelectTrigger>
              <SelectContent>
                {paymentMethods.map((method) => (
                  <SelectItem key={method} value={method}>
                    {method}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          {/* Date */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Fecha de pago
            </label>
            <Input
              type="date"
              value={formData.date}
              onChange={(e) => setFormData({ ...formData, date: e.target.value })}
              className="h-12 rounded-xl border-gray-200"
              required
            />
          </div>

          {/* Receipt Upload */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Comprobante (opcional)
            </label>
            <div className="border-2 border-dashed border-gray-300 rounded-xl p-4 text-center">
              <input
                type="file"
                accept="image/*,.pdf"
                onChange={handleFileUpload}
                className="hidden"
                id="receipt-upload"
              />
              <label htmlFor="receipt-upload" className="cursor-pointer">
                <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                <p className="text-sm text-gray-600">
                  {formData.receipt ? formData.receipt.name : 'Subir comprobante'}
                </p>
                <p className="text-xs text-gray-500 mt-1">
                  PDF, JPG, PNG (máx. 5MB)
                </p>
              </label>
            </div>
          </div>

          {/* Notes */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Observaciones (opcional)
            </label>
            <Textarea
              placeholder="Notas adicionales sobre el pago..."
              value={formData.notes}
              onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
              className="min-h-[80px] rounded-xl border-gray-200"
            />
          </div>

          {/* Action Buttons */}
          <div className="space-y-3 pt-4">
            <Button
              type="submit"
              disabled={isLoading || !formData.amount || !formData.concept || !formData.method}
              className="w-full h-12 bg-green-500 hover:bg-green-600 text-white rounded-xl"
            >
              <DollarSign className="w-4 h-4 mr-2" />
              {isLoading ? 'Procesando...' : 'Confirmar Pago'}
            </Button>
            
            <Button
              type="button"
              variant="outline"
              onClick={onClose}
              className="w-full h-12 border-gray-300 text-gray-700 rounded-xl"
            >
              Cancelar
            </Button>
          </div>
        </form>

        {/* Bottom padding */}
        <div className="h-6"></div>
      </div>
    </div>
  );
}