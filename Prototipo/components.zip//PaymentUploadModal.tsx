import { useState, useRef } from 'react';
import { X, Upload, FileText, Check, AlertCircle, User, Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';
import { Badge } from './ui/badge';
import { getAvatarByIndex } from '../utils/avatars';

// Mock data de estudiantes
const mockStudents = [
  {
    id: 1,
    name: 'Ana María López',
    grade: '5to Primaria',
    section: 'A',
    avatar: getAvatarByIndex(0, 'students')
  },
  {
    id: 2,
    name: 'Carlos Roberto Mendez',
    grade: '3ro Secundaria',
    section: 'B',
    avatar: getAvatarByIndex(1, 'students')
  },
  {
    id: 3,
    name: 'María José Hernández',
    grade: '2do Primaria',
    section: 'A',
    avatar: getAvatarByIndex(2, 'students')
  }
];

export function PaymentUploadModal({ onClose, onSuccess }) {
  const [currentStep, setCurrentStep] = useState(1);
  const [isLoading, setIsLoading] = useState(false);
  const [uploadedFile, setUploadedFile] = useState(null);
  const [uploadProgress, setUploadProgress] = useState(0);
  const fileInputRef = useRef(null);
  
  const [formData, setFormData] = useState({
    studentId: '',
    concept: '',
    date: new Date().toISOString().split('T')[0],
    notes: ''
  });

  const [selectedStudent, setSelectedStudent] = useState(null);

  const handleFileUpload = (event) => {
    const file = event.target.files[0];
    if (!file) return;

    // Validate file type
    if (file.type !== 'application/pdf') {
      alert('Solo se permiten archivos PDF');
      return;
    }

    // Validate file size (10MB)
    if (file.size > 10 * 1024 * 1024) {
      alert('El archivo no puede ser mayor a 10MB');
      return;
    }

    setUploadedFile(file);
    
    // Simulate upload progress
    setUploadProgress(0);
    const interval = setInterval(() => {
      setUploadProgress(prev => {
        if (prev >= 100) {
          clearInterval(interval);
          return 100;
        }
        return prev + 10;
      });
    }, 100);
  };

  const handleDragOver = (e) => {
    e.preventDefault();
  };

  const handleDrop = (e) => {
    e.preventDefault();
    const files = e.dataTransfer.files;
    if (files.length > 0) {
      const fakeEvent = { target: { files } };
      handleFileUpload(fakeEvent);
    }
  };

  const validateStep = (step) => {
    switch (step) {
      case 1:
        return uploadedFile !== null;
      case 2:
        return selectedStudent !== null;
      case 3:
        return formData.concept && formData.date;
      default:
        return true;
    }
  };

  const handleSubmit = async () => {
    setIsLoading(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 2000));
    
    // Here you would upload the file and save the payment data
    console.log('Upload data:', { 
      file: uploadedFile, 
      formData, 
      student: selectedStudent 
    });
    
    setIsLoading(false);
    onSuccess();
  };

  const formatFileSize = (bytes) => {
    if (bytes === 0) return '0 Bytes';
    const k = 1024;
    const sizes = ['Bytes', 'KB', 'MB', 'GB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const renderStep = () => {
    switch (currentStep) {
      case 1:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Upload className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Subir Comprobante
              </h3>
              <p className="text-gray-600">
                Sube el documento PDF del comprobante de pago
              </p>
            </div>

            {/* Upload Area */}
            {!uploadedFile ? (
              <div
                onDragOver={handleDragOver}
                onDrop={handleDrop}
                className="border-2 border-dashed border-gray-300 rounded-xl p-8 text-center hover:border-green-400 transition-colors cursor-pointer"
                onClick={() => fileInputRef.current?.click()}
              >
                <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                <h4 className="text-lg font-medium text-gray-900 mb-2">
                  Arrastra tu archivo aquí
                </h4>
                <p className="text-gray-600 mb-4">
                  o haz clic para seleccionar un archivo
                </p>
                <div className="text-sm text-gray-500">
                  <p>Solo archivos PDF</p>
                  <p>Tamaño máximo: 10MB</p>
                </div>
                <input
                  ref={fileInputRef}
                  type="file"
                  accept=".pdf"
                  onChange={handleFileUpload}
                  className="hidden"
                />
              </div>
            ) : (
              <div className="border border-green-300 rounded-xl p-6 bg-green-50">
                <div className="flex items-center justify-between">
                  <div className="flex items-center">
                    <div className="w-12 h-12 bg-green-500 rounded-lg flex items-center justify-center mr-4">
                      <FileText className="w-6 h-6 text-white" />
                    </div>
                    <div>
                      <h4 className="font-medium text-green-900">{uploadedFile.name}</h4>
                      <p className="text-sm text-green-700">
                        {formatFileSize(uploadedFile.size)}
                      </p>
                    </div>
                  </div>
                  <div className="flex items-center">
                    {uploadProgress === 100 ? (
                      <div className="w-8 h-8 bg-green-500 rounded-full flex items-center justify-center">
                        <Check className="w-5 h-5 text-white" />
                      </div>
                    ) : (
                      <div className="text-green-700 font-medium">
                        {uploadProgress}%
                      </div>
                    )}
                  </div>
                </div>
                
                {uploadProgress < 100 && (
                  <div className="mt-4">
                    <div className="w-full bg-green-200 rounded-full h-2">
                      <div 
                        className="bg-green-500 h-2 rounded-full transition-all duration-300"
                        style={{ width: `${uploadProgress}%` }}
                      ></div>
                    </div>
                  </div>
                )}

                <div className="mt-4 flex justify-center">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => {
                      setUploadedFile(null);
                      setUploadProgress(0);
                    }}
                    className="text-green-700 border-green-300 hover:bg-green-100"
                  >
                    Cambiar archivo
                  </Button>
                </div>
              </div>
            )}

            {/* File Requirements */}
            <div className="bg-blue-50 border border-blue-200 rounded-xl p-4">
              <h4 className="font-medium text-blue-900 mb-2">Requisitos del archivo:</h4>
              <ul className="text-sm text-blue-700 space-y-1">
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></div>
                  Formato PDF únicamente
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></div>
                  Tamaño máximo de 10MB
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></div>
                  Documento legible y completo
                </li>
                <li className="flex items-center">
                  <div className="w-1.5 h-1.5 bg-blue-500 rounded-full mr-2"></div>
                  Incluir fecha, monto y referencia
                </li>
              </ul>
            </div>
          </div>
        );

      case 2:
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <User className="w-8 h-8 text-blue-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Asociar Estudiante
              </h3>
              <p className="text-gray-600">
                Selecciona el estudiante al que corresponde este pago
              </p>
            </div>

            {/* Uploaded File Info */}
            <div className="bg-gray-50 rounded-xl p-4 mb-6">
              <div className="flex items-center">
                <FileText className="w-5 h-5 text-gray-600 mr-2" />
                <div>
                  <p className="font-medium text-gray-900">Archivo subido:</p>
                  <p className="text-sm text-gray-600">{uploadedFile?.name}</p>
                </div>
              </div>
            </div>

            {/* Students List */}
            <div className="space-y-2 max-h-80 overflow-y-auto">
              {mockStudents.map((student) => (
                <button
                  key={student.id}
                  onClick={() => {
                    setSelectedStudent(student);
                    setFormData({ ...formData, studentId: student.id });
                  }}
                  className={`w-full p-4 rounded-xl border text-left transition-all ${
                    selectedStudent?.id === student.id
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-200 hover:border-gray-300 hover:bg-gray-50'
                  }`}
                >
                  <div className="flex items-center">
                    <div className="w-12 h-12 rounded-full overflow-hidden bg-gray-200 mr-3">
                      <img
                        src={student.avatar}
                        alt={student.name}
                        className="w-full h-full object-cover"
                      />
                    </div>
                    <div className="flex-1">
                      <h4 className="font-medium text-gray-900">{student.name}</h4>
                      <p className="text-sm text-gray-600">
                        {student.grade} - Sección {student.section}
                      </p>
                    </div>
                    {selectedStudent?.id === student.id && (
                      <div className="w-6 h-6 bg-blue-500 rounded-full flex items-center justify-center">
                        <Check className="w-4 h-4 text-white" />
                      </div>
                    )}
                  </div>
                </button>
              ))}
            </div>
          </div>
        );

      case 3:
        return (
          <div className="space-y-4">
            <div className="text-center mb-6">
              <div className="w-16 h-16 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Calendar className="w-8 h-8 text-purple-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Información Adicional
              </h3>
              <p className="text-gray-600">
                Completa los detalles del pago
              </p>
            </div>

            {/* Student and File Info */}
            <div className="bg-gray-50 rounded-xl p-4 mb-6 space-y-3">
              <div className="flex items-center">
                <div className="w-8 h-8 rounded-full overflow-hidden bg-gray-200 mr-3">
                  <img
                    src={selectedStudent?.avatar}
                    alt={selectedStudent?.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                <div>
                  <p className="font-medium text-gray-900">{selectedStudent?.name}</p>
                  <p className="text-sm text-gray-600">
                    {selectedStudent?.grade} - Sección {selectedStudent?.section}
                  </p>
                </div>
              </div>
              <div className="flex items-center text-sm text-gray-600">
                <FileText className="w-4 h-4 mr-2" />
                {uploadedFile?.name}
              </div>
            </div>

            {/* Additional Form */}
            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Concepto del pago *
                </label>
                <Select 
                  value={formData.concept} 
                  onValueChange={(value) => setFormData({ ...formData, concept: value })}
                >
                  <SelectTrigger className="h-12 rounded-xl border-gray-200">
                    <SelectValue placeholder="Selecciona el concepto" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="Mensualidad">Mensualidad</SelectItem>
                    <SelectItem value="Inscripción">Inscripción</SelectItem>
                    <SelectItem value="Matrícula">Matrícula</SelectItem>
                    <SelectItem value="Material Didáctico">Material Didáctico</SelectItem>
                    <SelectItem value="Actividades">Actividades Extracurriculares</SelectItem>
                    <SelectItem value="Otro">Otro</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Fecha del pago *
                </label>
                <Input
                  type="date"
                  value={formData.date}
                  onChange={(e) => setFormData({ ...formData, date: e.target.value })}
                  className="h-12 rounded-xl border-gray-200"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Notas adicionales (opcional)
                </label>
                <Textarea
                  placeholder="Información adicional sobre el pago..."
                  value={formData.notes}
                  onChange={(e) => setFormData({ ...formData, notes: e.target.value })}
                  className="min-h-[80px] rounded-xl border-gray-200"
                />
              </div>
            </div>
          </div>
        );

      case 4:
        return (
          <div className="space-y-6">
            <div className="text-center">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Check className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-lg font-semibold text-gray-900 mb-2">
                Confirmar Carga
              </h3>
              <p className="text-gray-600">
                Revisa los detalles antes de enviar el comprobante
              </p>
            </div>

            {/* Summary */}
            <div className="bg-gray-50 rounded-xl p-6 space-y-4">
              <div className="flex justify-between">
                <span className="text-gray-600">Estudiante:</span>
                <span className="font-medium">{selectedStudent?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Grado:</span>
                <span className="font-medium">{selectedStudent?.grade} - Sección {selectedStudent?.section}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Concepto:</span>
                <span className="font-medium">{formData.concept}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Fecha:</span>
                <span className="font-medium">{formData.date}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Archivo:</span>
                <span className="font-medium">{uploadedFile?.name}</span>
              </div>
              <div className="flex justify-between">
                <span className="text-gray-600">Tamaño:</span>
                <span className="font-medium">{formatFileSize(uploadedFile?.size || 0)}</span>
              </div>
              {formData.notes && (
                <div>
                  <span className="text-gray-600">Notas:</span>
                  <p className="text-sm text-gray-800 mt-1">{formData.notes}</p>
                </div>
              )}
            </div>

            <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
              <div className="flex items-start">
                <AlertCircle className="w-5 h-5 text-yellow-600 mr-2 mt-0.5" />
                <div>
                  <p className="font-medium text-yellow-900">Procesamiento</p>
                  <p className="text-sm text-yellow-700">
                    El comprobante será revisado por el personal administrativo. 
                    Recibirás una notificación una vez sea verificado y aplicado al estado del estudiante.
                  </p>
                </div>
              </div>
            </div>
          </div>
        );

      default:
        return null;
    }
  };

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-3xl w-full max-w-2xl max-h-[90vh] overflow-hidden">
        {/* Header */}
        <div className="flex items-center justify-between p-6 border-b border-gray-100">
          <div>
            <h2 className="text-xl font-semibold text-gray-900">
              Subir Comprobante de Pago
            </h2>
            <p className="text-sm text-gray-600">Paso {currentStep} de 4</p>
          </div>
          <button 
            onClick={onClose}
            className="w-10 h-10 bg-gray-100 rounded-full flex items-center justify-center hover:bg-gray-200"
          >
            <X className="w-5 h-5 text-gray-600" />
          </button>
        </div>

        {/* Progress */}
        <div className="px-6 py-4">
          <div className="w-full bg-gray-200 rounded-full h-2">
            <div 
              className="bg-green-500 h-2 rounded-full transition-all duration-300"
              style={{ width: `${(currentStep / 4) * 100}%` }}
            ></div>
          </div>
        </div>

        {/* Content */}
        <div className="px-6 py-4 max-h-[60vh] overflow-y-auto">
          {renderStep()}
        </div>

        {/* Actions */}
        <div className="flex justify-between p-6 border-t border-gray-100">
          <Button
            variant="outline"
            onClick={() => {
              if (currentStep > 1) {
                setCurrentStep(currentStep - 1);
              } else {
                onClose();
              }
            }}
            className="rounded-xl"
          >
            {currentStep === 1 ? 'Cancelar' : 'Anterior'}
          </Button>

          <Button
            onClick={() => {
              if (currentStep < 4) {
                setCurrentStep(currentStep + 1);
              } else {
                handleSubmit();
              }
            }}
            disabled={!validateStep(currentStep) || isLoading}
            className="bg-green-500 hover:bg-green-600 rounded-xl"
          >
            {isLoading ? 'Enviando...' : currentStep === 4 ? 'Enviar Comprobante' : 'Siguiente'}
          </Button>
        </div>
      </div>
    </div>
  );
}