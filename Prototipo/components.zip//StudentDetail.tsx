import { ChevronLeft, User, GraduationCap, CreditCard, Calendar } from 'lucide-react';
import { Button } from './ui/button';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';

export function StudentDetail({ student, onBack }) {
  const personalInfo = [
    { label: 'Nombre completo', value: student.name, icon: User },
    { label: 'Grado', value: `${student.grade} - Sección ${student.section}`, icon: GraduationCap },
    { label: 'Fecha de nacimiento', value: '15 de Mayo, 2010', icon: Calendar },
    { label: 'DPI', value: '1234567890101', icon: User },
    { label: 'Teléfono', value: '+502 1234-5678', icon: User },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="flex items-center p-4">
          <button onClick={onBack} className="mr-3 p-1">
            <ChevronLeft className="w-6 h-6 text-blue-500" />
          </button>
          <h1 className="text-xl font-semibold text-gray-900">Perfil del Estudiante</h1>
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-6">
        {/* Header with Photo */}
        <div className="bg-white rounded-2xl p-6 shadow-sm text-center">
          <div className="w-30 h-30 rounded-full overflow-hidden bg-gray-200 mx-auto mb-4">
            <img
              src={student.avatar}
              alt={student.name}
              className="w-full h-full object-cover"
            />
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">
            {student.name}
          </h2>
          <p className="text-gray-600">
            {student.grade} - Sección {student.section}
          </p>
        </div>

        {/* Information Cards */}
        <div className="space-y-4">
          {/* Personal Information */}
          <Card className="shadow-sm border-0 rounded-2xl">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Información Personal</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              {personalInfo.map((item, index) => {
                const IconComponent = item.icon;
                return (
                  <div key={index} className="flex items-center">
                    <div className="w-10 h-10 bg-gray-100 rounded-xl flex items-center justify-center mr-3">
                      <IconComponent className="w-5 h-5 text-gray-600" />
                    </div>
                    <div className="flex-1">
                      <p className="text-sm text-gray-600">{item.label}</p>
                      <p className="font-medium text-gray-900">{item.value}</p>
                    </div>
                  </div>
                );
              })}
            </CardContent>
          </Card>

          {/* Academic Information */}
          <Card className="shadow-sm border-0 rounded-2xl">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Información Académica</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm text-gray-600">Promedio General</p>
                  <p className="text-3xl font-bold text-gray-900">{student.average}</p>
                </div>
                <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                  student.average >= 85 ? 'bg-green-100 text-green-600' :
                  student.average >= 75 ? 'bg-yellow-100 text-yellow-600' :
                  'bg-red-100 text-red-600'
                }`}>
                  <GraduationCap className="w-8 h-8" />
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div 
                  className={`h-3 rounded-full ${
                    student.average >= 85 ? 'bg-green-500' :
                    student.average >= 75 ? 'bg-yellow-500' :
                    'bg-red-500'
                  }`}
                  style={{ width: `${student.average}%` }}
                ></div>
              </div>
            </CardContent>
          </Card>

          {/* Account Status */}
          <Card className="shadow-sm border-0 rounded-2xl">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Estado de Cuenta</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm text-gray-600">Estado</p>
                  <Badge 
                    variant={student.status === 'solvente' ? 'default' : 'destructive'}
                    className={`text-sm mt-1 ${
                      student.status === 'solvente' 
                        ? 'bg-green-500 hover:bg-green-600' 
                        : 'bg-red-500 hover:bg-red-600'
                    }`}
                  >
                    {student.status === 'solvente' ? 'Solvente' : 'Con Mora'}
                  </Badge>
                </div>
                <div className={`w-16 h-16 rounded-full flex items-center justify-center ${
                  student.status === 'solvente' ? 'bg-green-100 text-green-600' : 'bg-red-100 text-red-600'
                }`}>
                  <CreditCard className="w-8 h-8" />
                </div>
              </div>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-gray-600">Monto pagado:</span>
                  <span className="font-medium">Q 2,500.00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Monto total:</span>
                  <span className="font-medium">Q 3,000.00</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-gray-600">Saldo pendiente:</span>
                  <span className={`font-medium ${
                    student.status === 'solvente' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    Q {student.status === 'solvente' ? '0.00' : '500.00'}
                  </span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Attendance */}
          <Card className="shadow-sm border-0 rounded-2xl">
            <CardHeader className="pb-4">
              <CardTitle className="text-lg">Asistencia</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center justify-between mb-4">
                <div>
                  <p className="text-sm text-gray-600">Asistencia del mes</p>
                  <p className="text-2xl font-bold text-gray-900">95%</p>
                </div>
                <div className="w-16 h-16 bg-blue-100 text-blue-600 rounded-full flex items-center justify-center">
                  <Calendar className="w-8 h-8" />
                </div>
              </div>
              <div className="w-full bg-gray-200 rounded-full h-3">
                <div className="bg-blue-500 h-3 rounded-full" style={{ width: '95%' }}></div>
              </div>
              <p className="text-sm text-gray-600 mt-2">19 de 20 días presentes</p>
            </CardContent>
          </Card>
        </div>

        {/* Action Buttons */}
        <div className="space-y-3">
          <Button className="w-full h-12 bg-blue-500 hover:bg-blue-600 text-white rounded-xl">
            Ver Boleta de Calificaciones
          </Button>
          <Button 
            variant="outline" 
            className="w-full h-12 border-green-500 text-green-600 hover:bg-green-50 rounded-xl"
          >
            Registrar Pago
          </Button>
        </div>
      </div>

      {/* Bottom padding */}
      <div className="h-6"></div>
    </div>
  );
}