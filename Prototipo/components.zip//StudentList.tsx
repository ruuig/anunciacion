import { useState } from 'react';
import { ChevronLeft, Search, Plus, ChevronRight, DollarSign } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { StudentDetail } from './StudentDetail';
import { getAvatarByIndex } from '../utils/avatars';

const mockStudents = [
  {
    id: 1,
    name: 'Ana María López',
    grade: '5to Primaria',
    section: 'A',
    avatar: getAvatarByIndex(0, 'students'),
    status: 'solvente',
    average: 85,
    paymentInfo: {
      totalAmount: 3000,
      paidAmount: 3000,
      pendingAmount: 0,
      lastPayment: '2024-01-15'
    }
  },
  {
    id: 2,
    name: 'Carlos Roberto Mendez',
    grade: '3ro Secundaria',
    section: 'B',
    avatar: getAvatarByIndex(1, 'students'),
    status: 'mora',
    average: 78,
    paymentInfo: {
      totalAmount: 3500,
      paidAmount: 2800,
      pendingAmount: 700,
      lastPayment: '2023-12-10'
    }
  },
  {
    id: 3,
    name: 'María José Hernández',
    grade: '2do Primaria',
    section: 'A',
    avatar: getAvatarByIndex(2, 'students'),
    status: 'solvente',
    average: 92,
    paymentInfo: {
      totalAmount: 2800,
      paidAmount: 2800,
      pendingAmount: 0,
      lastPayment: '2024-01-20'
    }
  },
  {
    id: 4,
    name: 'Diego Alexander Ruiz',
    grade: '1ro Secundaria',
    section: 'C',
    avatar: getAvatarByIndex(3, 'students'),
    status: 'solvente',
    average: 88,
    paymentInfo: {
      totalAmount: 3200,
      paidAmount: 2400,
      pendingAmount: 800,
      lastPayment: '2023-11-25'
    }
  },
  {
    id: 5,
    name: 'Sofía Isabella García',
    grade: '4to Primaria',
    section: 'B',
    avatar: getAvatarByIndex(4, 'students'),
    status: 'mora',
    average: 75,
    paymentInfo: {
      totalAmount: 2900,
      paidAmount: 2100,
      pendingAmount: 800,
      lastPayment: '2023-12-05'
    }
  },
  {
    id: 6,
    name: 'Luis Fernando Morales',
    grade: '1ro Primaria',
    section: 'A',
    avatar: getAvatarByIndex(5, 'students'),
    status: 'solvente',
    average: 89,
    paymentInfo: {
      totalAmount: 2500,
      paidAmount: 2500,
      pendingAmount: 0,
      lastPayment: '2024-01-18'
    }
  },
  {
    id: 7,
    name: 'Carmen Elena Rodríguez',
    grade: '2do Primaria',
    section: 'B',
    avatar: getAvatarByIndex(6, 'students'),
    status: 'solvente',
    average: 91,
    paymentInfo: {
      totalAmount: 2800,
      paidAmount: 2800,
      pendingAmount: 0,
      lastPayment: '2024-01-22'
    }
  },
  {
    id: 8,
    name: 'José Antonio Paz',
    grade: '3ro Secundaria',
    section: 'A',
    avatar: getAvatarByIndex(7, 'students'),
    status: 'mora',
    average: 68,
    paymentInfo: {
      totalAmount: 3500,
      paidAmount: 2650,
      pendingAmount: 850,
      lastPayment: '2023-11-30'
    }
  }
];

const mockGrades = [
  { name: 'Preprimaria', sections: ['A', 'B'] },
  { name: '1ro Primaria', sections: ['A', 'B', 'C'] },
  { name: '2do Primaria', sections: ['A', 'B'] },
  { name: '3ro Primaria', sections: ['A', 'B', 'C'] },
  { name: '4to Primaria', sections: ['A', 'B'] },
  { name: '5to Primaria', sections: ['A', 'B'] },
  { name: '6to Primaria', sections: ['A', 'B'] },
  { name: '1ro Secundaria', sections: ['A', 'B', 'C'] },
  { name: '2do Secundaria', sections: ['A', 'B'] },
  { name: '3ro Secundaria', sections: ['A', 'B'] }
];

const levelFilters = ['Todos', 'Preprimaria', 'Primaria', 'Secundaria'];

export function StudentList({ user, onBack }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [levelFilter, setLevelFilter] = useState('Todos');
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [selectedSection, setSelectedSection] = useState('all');
  const [selectedStudent, setSelectedStudent] = useState(null);

  const canEdit = user?.permissions?.includes('edit_students') || user?.permissions?.includes('edit_all');
  const canViewPayments = user?.permissions?.includes('manage_payments') || user?.permissions?.includes('view_all');

  // Get available sections based on selected grade
  const availableSections = selectedGrade === 'all' 
    ? []
    : mockGrades.find(g => g.name === selectedGrade)?.sections || [];

  const filteredStudents = mockStudents.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase());
    
    // Level filter (Todos, Preprimaria, Primaria, Secundaria)
    const matchesLevel = levelFilter === 'Todos' || 
      (levelFilter === 'Preprimaria' && student.grade.includes('Preprimaria')) ||
      (levelFilter === 'Primaria' && student.grade.includes('Primaria')) ||
      (levelFilter === 'Secundaria' && student.grade.includes('Secundaria'));
    
    // Specific grade filter
    const matchesGrade = selectedGrade === 'all' || student.grade === selectedGrade;
    
    // Section filter
    const matchesSection = selectedSection === 'all' || student.section === selectedSection;
    
    return matchesSearch && matchesLevel && matchesGrade && matchesSection;
  });

  if (selectedStudent) {
    return (
      <StudentDetail 
        student={selectedStudent} 
        onBack={() => setSelectedStudent(null)} 
      />
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation Bar */}
      <div className="bg-white border-b border-gray-100 sticky top-0 z-10">
        <div className="flex items-center justify-between p-4">
          <div className="flex items-center">
            <button onClick={onBack} className="mr-3 p-1">
              <ChevronLeft className="w-6 h-6 text-blue-500" />
            </button>
            <h1 className="text-xl font-semibold text-gray-900">Estudiantes</h1>
          </div>
          {canEdit && (
            <Button size="sm" className="bg-blue-500 hover:bg-blue-600 rounded-xl">
              <Plus className="w-4 h-4" />
            </Button>
          )}
        </div>
      </div>

      {/* Content */}
      <div className="p-4 space-y-4">
        {/* Search Bar */}
        <div className="relative">
          <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
          <Input
            type="text"
            placeholder="Buscar estudiante..."
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
            className="pl-10 h-12 bg-white border border-gray-200 rounded-xl"
          />
        </div>

        {/* Level Filter Chips */}
        <div className="flex space-x-2 overflow-x-auto pb-2">
          {levelFilters.map((filter) => (
            <button
              key={filter}
              onClick={() => {
                setLevelFilter(filter);
                setSelectedGrade('all');
                setSelectedSection('all');
              }}
              className={`
                px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all
                ${levelFilter === filter
                  ? 'bg-blue-500 text-white'
                  : 'bg-white text-gray-600 border border-gray-200'
                }
              `}
            >
              {filter}
            </button>
          ))}
        </div>

        {/* Specific Grade and Section Filters */}
        <div className="grid grid-cols-2 gap-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Filtrar por Grado Específico
            </label>
            <Select value={selectedGrade} onValueChange={(value) => {
              setSelectedGrade(value);
              setSelectedSection('all');
            }}>
              <SelectTrigger className="h-12 rounded-xl border-gray-200">
                <SelectValue placeholder="Todos los grados" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todos los grados</SelectItem>
                {mockGrades.map((grade, index) => (
                  <SelectItem key={index} value={grade.name}>
                    {grade.name}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Filtrar por Sección
            </label>
            <Select 
              value={selectedSection} 
              onValueChange={setSelectedSection}
              disabled={selectedGrade === 'all'}
            >
              <SelectTrigger className="h-12 rounded-xl border-gray-200">
                <SelectValue placeholder="Todas las secciones" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="all">Todas las secciones</SelectItem>
                {availableSections.map((section) => (
                  <SelectItem key={section} value={section}>
                    Sección {section}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
            {selectedGrade === 'all' && (
              <p className="text-xs text-gray-500 mt-1">
                Selecciona un grado primero
              </p>
            )}
          </div>
        </div>

        {/* Students List */}
        <div className="space-y-3">
          {filteredStudents.map((student) => (
            <button
              key={student.id}
              onClick={() => setSelectedStudent(student)}
              className="w-full bg-white rounded-2xl p-4 shadow-sm hover:shadow-md transition-all duration-200 active:scale-98"
            >
              <div className="flex items-center">
                <div className="w-14 h-14 rounded-full overflow-hidden bg-gray-200 mr-4">
                  <img
                    src={student.avatar}
                    alt={student.name}
                    className="w-full h-full object-cover"
                  />
                </div>
                
                <div className="flex-1 text-left">
                  <h3 className="font-semibold text-gray-900 mb-1">
                    {student.name}
                  </h3>
                  <p className="text-sm text-gray-600">
                    {student.grade} - Sección {student.section}
                  </p>
                  
                  {/* Payment Information - Only for Secretary */}
                  {canViewPayments && (
                    <div className="mt-2 p-2 bg-gray-50 rounded-lg">
                      <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center text-gray-600">
                          <DollarSign className="w-3 h-3 mr-1" />
                          <span>Pagado: Q {student.paymentInfo.paidAmount.toLocaleString()}</span>
                        </div>
                        {student.paymentInfo.pendingAmount > 0 && (
                          <span className="text-red-600 font-medium">
                            Debe: Q {student.paymentInfo.pendingAmount.toLocaleString()}
                          </span>
                        )}
                      </div>
                      <div className="mt-1">
                        <div className="w-full bg-gray-200 rounded-full h-1.5">
                          <div 
                            className={`h-1.5 rounded-full ${
                              student.status === 'solvente' ? 'bg-green-500' : 'bg-red-500'
                            }`}
                            style={{ 
                              width: `${(student.paymentInfo.paidAmount / student.paymentInfo.totalAmount) * 100}%` 
                            }}
                          ></div>
                        </div>
                      </div>
                      <p className="text-xs text-gray-500 mt-1">
                        Último pago: {student.paymentInfo.lastPayment}
                      </p>
                    </div>
                  )}
                </div>

                <div className="flex flex-col items-end space-y-1">
                  <Badge 
                    variant={student.status === 'solvente' ? 'default' : 'destructive'}
                    className={`text-xs ${
                      student.status === 'solvente' 
                        ? 'bg-green-500 hover:bg-green-600' 
                        : 'bg-red-500 hover:bg-red-600'
                    }`}
                  >
                    {student.status === 'solvente' ? 'Solvente' : 'Mora'}
                  </Badge>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </div>
            </button>
          ))}
        </div>

        {filteredStudents.length === 0 && (
          <div className="text-center py-12">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Search className="w-8 h-8 text-gray-400" />
            </div>
            <h3 className="text-lg font-medium text-gray-900 mb-2">
              No se encontraron estudiantes
            </h3>
            <p className="text-gray-600">
              Intenta con otro término de búsqueda
            </p>
          </div>
        )}
      </div>

      {/* Bottom padding */}
      <div className="h-6"></div>
    </div>
  );
}