import { useState } from 'react';
import { 
  ChevronLeft, 
  Plus, 
  Search, 
  Edit, 
  UserPlus,
  Users,
  GraduationCap,
  MapPin
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { CreateStudentModal } from './CreateStudentModal';
import { getAvatarByIndex } from '../utils/avatars';

const mockStudents = [
  {
    id: 1,
    name: 'Ana María López',
    grade: '5to Primaria',
    section: 'A',
    dpi: '1234567890101',
    birthDate: '2010-05-15',
    phone: '+502 1234-5678',
    email: 'ana.lopez@ejemplo.com',
    address: 'Zona 1, Ciudad de Guatemala',
    parentName: 'Carlos López',
    parentPhone: '+502 2345-6789',
    status: 'active',
    enrollmentDate: '2024-01-15',
    avatar: getAvatarByIndex(0, 'students')
  },
  {
    id: 2,
    name: 'Carlos Roberto Mendez',
    grade: '3ro Secundaria',
    section: 'B',
    dpi: '2345678901012',
    birthDate: '2008-08-20',
    phone: '+502 3456-7890',
    email: 'carlos.mendez@ejemplo.com',
    address: 'Zona 10, Ciudad de Guatemala',
    parentName: 'María Mendez',
    parentPhone: '+502 4567-8901',
    status: 'active',
    enrollmentDate: '2024-01-10',
    avatar: getAvatarByIndex(1, 'students')
  },
  {
    id: 3,
    name: 'María José Hernández',
    grade: '2do Primaria',
    section: 'A',
    dpi: '3456789012013',
    birthDate: '2012-03-10',
    phone: '+502 5678-9012',
    email: 'maria.hernandez@ejemplo.com',
    address: 'Zona 7, Ciudad de Guatemala',
    parentName: 'José Hernández',
    parentPhone: '+502 6789-0123',
    status: 'active',
    enrollmentDate: '2024-01-12',
    avatar: getAvatarByIndex(2, 'students')
  }
];

const mockGrades = [
  { id: 1, name: 'Preprimaria', sections: ['A', 'B'] },
  { id: 2, name: '1ro Primaria', sections: ['A', 'B', 'C'] },
  { id: 3, name: '2do Primaria', sections: ['A', 'B'] },
  { id: 4, name: '3ro Primaria', sections: ['A', 'B', 'C'] },
  { id: 5, name: '4to Primaria', sections: ['A', 'B'] },
  { id: 6, name: '5to Primaria', sections: ['A', 'B'] },
  { id: 7, name: '6to Primaria', sections: ['A', 'B'] },
  { id: 8, name: '1ro Secundaria', sections: ['A', 'B'] },
  { id: 9, name: '2do Secundaria', sections: ['A', 'B'] },
  { id: 10, name: '3ro Secundaria', sections: ['A', 'B'] }
];

export function StudentManagement({ user, onBack }) {
  const [students, setStudents] = useState(mockStudents);
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGrade, setSelectedGrade] = useState('all');
  const [selectedSection, setSelectedSection] = useState('all');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [editingStudent, setEditingStudent] = useState(null);

  const availableSections = selectedGrade === 'all' 
    ? []
    : mockGrades.find(g => g.name === selectedGrade)?.sections || [];

  const filteredStudents = students.filter(student => {
    const matchesSearch = student.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         student.dpi.includes(searchTerm) ||
                         student.parentName.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesGrade = selectedGrade === 'all' || student.grade === selectedGrade;
    const matchesSection = selectedSection === 'all' || student.section === selectedSection;
    
    return matchesSearch && matchesGrade && matchesSection;
  });

  const activeStudents = students.filter(s => s.status === 'active').length;
  const totalGrades = mockGrades.length;

  const handleCreateStudent = (newStudent) => {
    const student = {
      ...newStudent,
      id: students.length + 1,
      status: 'active',
      enrollmentDate: new Date().toISOString().split('T')[0],
      avatar: getAvatarByIndex(students.length, 'students')
    };
    setStudents([...students, student]);
  };

  const handleEditStudent = (studentId, updatedStudent) => {
    setStudents(students.map(s => 
      s.id === studentId ? { ...s, ...updatedStudent } : s
    ));
  };

  const toggleStudentStatus = (studentId) => {
    setStudents(students.map(s => 
      s.id === studentId 
        ? { ...s, status: s.status === 'active' ? 'inactive' : 'active' }
        : s
    ));
  };

  const canEdit = user.permissions?.includes('edit_students') || user.permissions?.includes('edit_all');
  const canCreate = user.permissions?.includes('manage_students') || user.permissions?.includes('edit_all');

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">Administración de Estudiantes</h2>
            <p className="text-gray-600">Gestiona información y asignación de estudiantes</p>
          </div>
          {canCreate && (
            <Button 
              onClick={() => setShowCreateModal(true)}
              className="bg-blue-500 hover:bg-blue-600 rounded-xl"
            >
              <Plus className="w-4 h-4 mr-2" />
              Nuevo Estudiante
            </Button>
          )}
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-blue-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-blue-800">{activeStudents}</p>
            <p className="text-sm text-blue-600">Estudiantes Activos</p>
          </div>
          <div className="bg-green-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-green-800">{totalGrades}</p>
            <p className="text-sm text-green-600">Grados Disponibles</p>
          </div>
          <div className="bg-purple-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-purple-800">{filteredStudents.length}</p>
            <p className="text-sm text-purple-600">En Filtro Actual</p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <Card className="shadow-sm border-0 rounded-2xl">
        <CardContent className="p-4 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Buscar por nombre, DPI o padre de familia..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 bg-gray-50 border-gray-200 rounded-xl"
            />
          </div>

          {/* Filters */}
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Filtrar por Grado
              </label>
              <Select value={selectedGrade} onValueChange={(value) => {
                setSelectedGrade(value);
                setSelectedSection('all');
              }}>
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Todos los grados" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todos los grados</SelectItem>
                  {mockGrades.map((grade) => (
                    <SelectItem key={grade.id} value={grade.name}>
                      {grade.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Filtrar por Sección
              </label>
              <Select 
                value={selectedSection} 
                onValueChange={setSelectedSection}
                disabled={selectedGrade === 'all'}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue placeholder="Todas las secciones" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">Todas las secciones</SelectItem>
                  {availableSections.map((section) => (
                    <SelectItem key={section} value={section}>
                      Sección {section}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Students List */}
      <div className="space-y-3">
        {filteredStudents.map((student) => (
          <Card key={student.id} className="shadow-sm border-0 rounded-2xl">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center flex-1">
                  <div className="w-14 h-14 rounded-full overflow-hidden bg-gray-200 mr-4">
                    <img
                      src={student.avatar}
                      alt={student.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center mb-1">
                      <h3 className="font-semibold text-gray-900 mr-2">{student.name}</h3>
                      <Badge 
                        variant={student.status === 'active' ? 'default' : 'secondary'}
                        className={`text-xs ${
                          student.status === 'active' 
                            ? 'bg-green-500 hover:bg-green-600' 
                            : 'bg-gray-400 hover:bg-gray-500'
                        }`}
                      >
                        {student.status === 'active' ? 'Activo' : 'Inactivo'}
                      </Badge>
                    </div>
                    
                    <div className="space-y-1 text-sm text-gray-600">
                      <div className="flex items-center">
                        <GraduationCap className="w-4 h-4 mr-2" />
                        {student.grade} - Sección {student.section}
                      </div>
                      <div className="flex items-center">
                        <Users className="w-4 h-4 mr-2" />
                        Padre: {student.parentName}
                      </div>
                      <div className="flex items-center">
                        <MapPin className="w-4 h-4 mr-2" />
                        {student.address}
                      </div>
                    </div>
                    
                    <div className="mt-2">
                      <span className="text-xs text-gray-500">
                        DPI: {student.dpi} • Inscrito: {student.enrollmentDate}
                      </span>
                    </div>
                  </div>
                </div>

                {canEdit && (
                  <div className="flex flex-col space-y-2">
                    <Button
                      size="sm"
                      variant="outline"
                      onClick={() => setEditingStudent(student)}
                      className="rounded-lg"
                    >
                      <Edit className="w-4 h-4" />
                    </Button>
                    <Button
                      size="sm"
                      variant={student.status === 'active' ? 'destructive' : 'default'}
                      onClick={() => toggleStudentStatus(student.id)}
                      className="rounded-lg text-xs"
                    >
                      {student.status === 'active' ? 'Desactivar' : 'Activar'}
                    </Button>
                  </div>
                )}
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredStudents.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <Users className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No se encontraron estudiantes
          </h3>
          <p className="text-gray-600 mb-4">
            {searchTerm || selectedGrade !== 'all' || selectedSection !== 'all'
              ? 'Intenta con otros términos de búsqueda o filtros'
              : 'No hay estudiantes registrados en el sistema'
            }
          </p>
          {canCreate && (
            <Button 
              onClick={() => setShowCreateModal(true)}
              className="bg-blue-500 hover:bg-blue-600 rounded-xl"
            >
              <Plus className="w-4 h-4 mr-2" />
              Agregar Primer Estudiante
            </Button>
          )}
        </div>
      )}

      {/* Create/Edit Student Modal */}
      {(showCreateModal || editingStudent) && (
        <CreateStudentModal
          student={editingStudent}
          grades={mockGrades}
          onClose={() => {
            setShowCreateModal(false);
            setEditingStudent(null);
          }}
          onSuccess={(studentData) => {
            if (editingStudent) {
              handleEditStudent(editingStudent.id, studentData);
            } else {
              handleCreateStudent(studentData);
            }
          }}
        />
      )}
    </div>
  );
}