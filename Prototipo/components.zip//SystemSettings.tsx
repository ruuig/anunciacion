import { useState } from 'react';
import { 
  ChevronLeft, 
  Settings, 
  Calendar, 
  School, 
  Clock,
  Globe,
  Shield,
  Bell,
  Database,
  Download
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Switch } from './ui/switch';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { Textarea } from './ui/textarea';

const mockSettings = {
  school: {
    name: 'Nuestra Señora de la Anunciación',
    address: 'Zona 1, Ciudad de Guatemala',
    phone: '+502 2251-4545',
    email: 'info@colegioanunciacion.edu.gt',
    website: 'www.colegioanunciacion.edu.gt',
    logo: ''
  },
  academic: {
    currentYear: '2024',
    periods: 'bimestres',
    startDate: '2024-01-15',
    endDate: '2024-10-31',
    gradeScale: '0-100',
    passingGrade: '70'
  },
  system: {
    timezone: 'America/Guatemala',
    language: 'es',
    dateFormat: 'DD/MM/YYYY',
    currency: 'GTQ'
  },
  notifications: {
    emailNotifications: true,
    smsNotifications: false,
    pushNotifications: true,
    parentNotifications: true,
    teacherNotifications: true
  },
  backup: {
    autoBackup: true,
    backupFrequency: 'daily',
    lastBackup: '2024-01-15 02:00:00'
  }
};

export function SystemSettings({ user, onBack }) {
  const [settings, setSettings] = useState(mockSettings);
  const [hasChanges, setHasChanges] = useState(false);
  const [isSaving, setIsSaving] = useState(false);

  const updateSetting = (category, key, value) => {
    setSettings(prev => ({
      ...prev,
      [category]: {
        ...prev[category],
        [key]: value
      }
    }));
    setHasChanges(true);
  };

  const handleSave = async () => {
    setIsSaving(true);
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setHasChanges(false);
    setIsSaving(false);
    
    alert('Configuración guardada exitosamente');
  };

  const handleBackup = async () => {
    // Simulate backup process
    const result = confirm('¿Deseas crear una copia de seguridad de la base de datos?');
    if (result) {
      alert('Copia de seguridad iniciada. Se te notificará cuando esté lista.');
    }
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div className="flex items-center">
            <div className="w-12 h-12 bg-gray-500 rounded-xl flex items-center justify-center mr-4">
              <Settings className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-semibold text-gray-900 mb-2">Configuración del Sistema</h2>
              <p className="text-gray-600">Administra configuraciones generales del colegio</p>
            </div>
          </div>
          {hasChanges && (
            <Button 
              onClick={handleSave}
              disabled={isSaving}
              className="bg-green-500 hover:bg-green-600 rounded-xl"
            >
              {isSaving ? 'Guardando...' : 'Guardar Cambios'}
            </Button>
          )}
        </div>
        
        {hasChanges && (
          <div className="bg-yellow-50 border border-yellow-200 rounded-xl p-4">
            <div className="flex items-center">
              <div className="w-5 h-5 bg-yellow-500 rounded-full flex items-center justify-center mr-2">
                !
              </div>
              <p className="text-yellow-800">
                Tienes cambios sin guardar. No olvides guardarlos antes de salir.
              </p>
            </div>
          </div>
        )}
      </div>

      {/* School Information */}
      <Card className="shadow-sm border-0 rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center">
            <School className="w-5 h-5 mr-2" />
            Información del Colegio
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nombre del colegio
              </label>
              <Input
                value={settings.school.name}
                onChange={(e) => updateSetting('school', 'name', e.target.value)}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Teléfono principal
              </label>
              <Input
                value={settings.school.phone}
                onChange={(e) => updateSetting('school', 'phone', e.target.value)}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">
              Dirección
            </label>
            <Textarea
              value={settings.school.address}
              onChange={(e) => updateSetting('school', 'address', e.target.value)}
              className="min-h-[80px] rounded-xl border-gray-200"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Correo electrónico
              </label>
              <Input
                type="email"
                value={settings.school.email}
                onChange={(e) => updateSetting('school', 'email', e.target.value)}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Sitio web
              </label>
              <Input
                value={settings.school.website}
                onChange={(e) => updateSetting('school', 'website', e.target.value)}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Academic Configuration */}
      <Card className="shadow-sm border-0 rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Calendar className="w-5 h-5 mr-2" />
            Configuración Académica
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Año escolar actual
              </label>
              <Input
                value={settings.academic.currentYear}
                onChange={(e) => updateSetting('academic', 'currentYear', e.target.value)}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                División de periodos
              </label>
              <Select 
                value={settings.academic.periods} 
                onValueChange={(value) => updateSetting('academic', 'periods', value)}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="bimestres">Bimestres (4 periodos)</SelectItem>
                  <SelectItem value="trimestres">Trimestres (3 periodos)</SelectItem>
                  <SelectItem value="semestres">Semestres (2 periodos)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha de inicio
              </label>
              <Input
                type="date"
                value={settings.academic.startDate}
                onChange={(e) => updateSetting('academic', 'startDate', e.target.value)}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Fecha de finalización
              </label>
              <Input
                type="date"
                value={settings.academic.endDate}
                onChange={(e) => updateSetting('academic', 'endDate', e.target.value)}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Escala de calificaciones
              </label>
              <Select 
                value={settings.academic.gradeScale} 
                onValueChange={(value) => updateSetting('academic', 'gradeScale', value)}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="0-100">0 - 100 puntos</SelectItem>
                  <SelectItem value="0-10">0 - 10 puntos</SelectItem>
                  <SelectItem value="A-F">A, B, C, D, F</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Nota mínima para aprobar
              </label>
              <Input
                type="number"
                value={settings.academic.passingGrade}
                onChange={(e) => updateSetting('academic', 'passingGrade', e.target.value)}
                className="h-12 rounded-xl border-gray-200"
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* System Configuration */}
      <Card className="shadow-sm border-0 rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Globe className="w-5 h-5 mr-2" />
            Configuración del Sistema
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Zona horaria
              </label>
              <Select 
                value={settings.system.timezone} 
                onValueChange={(value) => updateSetting('system', 'timezone', value)}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="America/Guatemala">América/Guatemala (GMT-6)</SelectItem>
                  <SelectItem value="America/Mexico_City">América/Ciudad de México (GMT-6)</SelectItem>
                  <SelectItem value="America/New_York">América/Nueva York (GMT-5)</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Idioma del sistema
              </label>
              <Select 
                value={settings.system.language} 
                onValueChange={(value) => updateSetting('system', 'language', value)}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="es">Español</SelectItem>
                  <SelectItem value="en">English</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Formato de fecha
              </label>
              <Select 
                value={settings.system.dateFormat} 
                onValueChange={(value) => updateSetting('system', 'dateFormat', value)}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="DD/MM/YYYY">DD/MM/YYYY</SelectItem>
                  <SelectItem value="MM/DD/YYYY">MM/DD/YYYY</SelectItem>
                  <SelectItem value="YYYY-MM-DD">YYYY-MM-DD</SelectItem>
                </SelectContent>
              </Select>
            </div>
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Moneda
              </label>
              <Select 
                value={settings.system.currency} 
                onValueChange={(value) => updateSetting('system', 'currency', value)}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="GTQ">Quetzal (Q)</SelectItem>
                  <SelectItem value="USD">Dólar ($)</SelectItem>
                  <SelectItem value="EUR">Euro (€)</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Notifications */}
      <Card className="shadow-sm border-0 rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Bell className="w-5 h-5 mr-2" />
            Configuración de Notificaciones
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900">Notificaciones por email</p>
                <p className="text-sm text-gray-600">Enviar notificaciones importantes por correo</p>
              </div>
              <Switch
                checked={settings.notifications.emailNotifications}
                onCheckedChange={(checked) => updateSetting('notifications', 'emailNotifications', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900">Notificaciones SMS</p>
                <p className="text-sm text-gray-600">Enviar mensajes de texto para alertas urgentes</p>
              </div>
              <Switch
                checked={settings.notifications.smsNotifications}
                onCheckedChange={(checked) => updateSetting('notifications', 'smsNotifications', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900">Notificaciones push</p>
                <p className="text-sm text-gray-600">Notificaciones en tiempo real en la aplicación</p>
              </div>
              <Switch
                checked={settings.notifications.pushNotifications}
                onCheckedChange={(checked) => updateSetting('notifications', 'pushNotifications', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900">Notificar a padres</p>
                <p className="text-sm text-gray-600">Enviar actualizaciones automáticas a padres de familia</p>
              </div>
              <Switch
                checked={settings.notifications.parentNotifications}
                onCheckedChange={(checked) => updateSetting('notifications', 'parentNotifications', checked)}
              />
            </div>

            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900">Notificar a docentes</p>
                <p className="text-sm text-gray-600">Enviar recordatorios y actualizaciones a docentes</p>
              </div>
              <Switch
                checked={settings.notifications.teacherNotifications}
                onCheckedChange={(checked) => updateSetting('notifications', 'teacherNotifications', checked)}
              />
            </div>
          </div>
        </CardContent>
      </Card>

      {/* Backup Configuration */}
      <Card className="shadow-sm border-0 rounded-2xl">
        <CardHeader>
          <CardTitle className="flex items-center">
            <Database className="w-5 h-5 mr-2" />
            Respaldo de Datos
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="font-medium text-gray-900">Respaldo automático</p>
              <p className="text-sm text-gray-600">Crear copias de seguridad automáticamente</p>
            </div>
            <Switch
              checked={settings.backup.autoBackup}
              onCheckedChange={(checked) => updateSetting('backup', 'autoBackup', checked)}
            />
          </div>

          {settings.backup.autoBackup && (
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Frecuencia de respaldo
              </label>
              <Select 
                value={settings.backup.backupFrequency} 
                onValueChange={(value) => updateSetting('backup', 'backupFrequency', value)}
              >
                <SelectTrigger className="h-12 rounded-xl border-gray-200">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="daily">Diario</SelectItem>
                  <SelectItem value="weekly">Semanal</SelectItem>
                  <SelectItem value="monthly">Mensual</SelectItem>
                </SelectContent>
              </Select>
            </div>
          )}

          <div className="bg-gray-50 rounded-xl p-4">
            <div className="flex items-center justify-between">
              <div>
                <p className="font-medium text-gray-900">Último respaldo</p>
                <p className="text-sm text-gray-600">{settings.backup.lastBackup}</p>
              </div>
              <Button
                onClick={handleBackup}
                variant="outline"
                className="rounded-xl"
              >
                <Download className="w-4 h-4 mr-2" />
                Respaldar Ahora
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}