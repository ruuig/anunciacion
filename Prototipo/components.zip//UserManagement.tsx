import { useState } from 'react';
import { 
  ChevronLeft, 
  Plus, 
  Search, 
  Edit, 
  Shield, 
  User,
  Mail,
  Phone,
  MoreVertical,
  UserPlus
} from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Badge } from './ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from './ui/card';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from './ui/select';
import { CreateUserModal } from './CreateUserModal';
import { getAvatarByIndex } from '../utils/avatars';

const mockUsers = [
  {
    id: 1,
    name: 'Roberto Díaz',
    email: 'roberto.diaz@colegio.edu',
    phone: '+502 1234-5678',
    role: 'Director',
    permissions: ['view_all', 'edit_all', 'delete_all', 'manage_users', 'manage_grades', 'manage_students'],
    status: 'active',
    lastLogin: '2024-01-15 08:30',
    avatar: getAvatarByIndex(0, 'teachers')
  },
  {
    id: 2,
    name: 'Ana Rodríguez',
    email: 'ana.rodriguez@colegio.edu',
    phone: '+502 2345-6789',
    role: 'Secretaria',
    permissions: ['view_students', 'edit_students', 'manage_payments', 'view_reports'],
    status: 'active',
    lastLogin: '2024-01-15 07:45',
    avatar: getAvatarByIndex(1, 'teachers')
  },
  {
    id: 3,
    name: 'María González',
    email: 'maria.gonzalez@colegio.edu',
    phone: '+502 3456-7890',
    role: 'Docente',
    permissions: ['view_students', 'manage_grades', 'view_attendance'],
    status: 'active',
    lastLogin: '2024-01-14 16:20',
    avatar: getAvatarByIndex(2, 'teachers')
  },
  {
    id: 4,
    name: 'Carlos Morales',
    email: 'carlos.morales@colegio.edu',
    phone: '+502 4567-8901',
    role: 'Docente',
    permissions: ['view_students', 'manage_grades', 'view_attendance'],
    status: 'inactive',
    lastLogin: '2024-01-10 12:15',
    avatar: getAvatarByIndex(3, 'teachers')
  }
];

const roleFilters = ['Todos', 'Director', 'Secretaria', 'Docente'];

const getRoleColor = (role) => {
  switch (role) {
    case 'Director':
      return 'bg-red-500 hover:bg-red-600';
    case 'Secretaria':
      return 'bg-blue-500 hover:bg-blue-600';
    case 'Docente':
      return 'bg-green-500 hover:bg-green-600';
    default:
      return 'bg-gray-500 hover:bg-gray-600';
  }
};

export function UserManagement({ user, onBack }) {
  const [searchTerm, setSearchTerm] = useState('');
  const [roleFilter, setRoleFilter] = useState('Todos');
  const [showCreateModal, setShowCreateModal] = useState(false);
  const [users, setUsers] = useState(mockUsers);

  const filteredUsers = users.filter(u => {
    const matchesSearch = u.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         u.email.toLowerCase().includes(searchTerm.toLowerCase());
    const matchesRole = roleFilter === 'Todos' || u.role === roleFilter;
    return matchesSearch && matchesRole;
  });

  const handleCreateUser = (newUser) => {
    const user = {
      ...newUser,
      id: users.length + 1,
      status: 'active',
      lastLogin: 'Nunca',
      avatar: getAvatarByIndex(users.length, 'teachers')
    };
    setUsers([...users, user]);
  };

  const toggleUserStatus = (userId) => {
    setUsers(users.map(u => 
      u.id === userId 
        ? { ...u, status: u.status === 'active' ? 'inactive' : 'active' }
        : u
    ));
  };

  return (
    <div className="space-y-4">
      {/* Header */}
      <div className="bg-white rounded-2xl p-6 shadow-sm">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h2 className="text-2xl font-semibold text-gray-900 mb-2">Gestión de Usuarios</h2>
            <p className="text-gray-600">Administra usuarios, roles y permisos del sistema</p>
          </div>
          <Button 
            onClick={() => setShowCreateModal(true)}
            className="bg-blue-500 hover:bg-blue-600 rounded-xl"
          >
            <Plus className="w-4 h-4 mr-2" />
            Nuevo Usuario
          </Button>
        </div>
        
        {/* Stats */}
        <div className="grid grid-cols-3 gap-4">
          <div className="bg-blue-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-blue-800">{users.filter(u => u.status === 'active').length}</p>
            <p className="text-sm text-blue-600">Usuarios Activos</p>
          </div>
          <div className="bg-green-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-green-800">{users.filter(u => u.role === 'Docente').length}</p>
            <p className="text-sm text-green-600">Docentes</p>
          </div>
          <div className="bg-orange-50 rounded-xl p-4 text-center">
            <p className="text-2xl font-bold text-orange-800">{users.filter(u => u.role === 'Director' || u.role === 'Secretaria').length}</p>
            <p className="text-sm text-orange-600">Personal Admin</p>
          </div>
        </div>
      </div>

      {/* Search and Filters */}
      <Card className="shadow-sm border-0 rounded-2xl">
        <CardContent className="p-4 space-y-4">
          {/* Search Bar */}
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 w-5 h-5" />
            <Input
              type="text"
              placeholder="Buscar por nombre o email..."
              value={searchTerm}
              onChange={(e) => setSearchTerm(e.target.value)}
              className="pl-10 h-12 bg-gray-50 border-gray-200 rounded-xl"
            />
          </div>

          {/* Role Filter */}
          <div className="flex space-x-2 overflow-x-auto pb-2">
            {roleFilters.map((filter) => (
              <button
                key={filter}
                onClick={() => setRoleFilter(filter)}
                className={`
                  px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all
                  ${roleFilter === filter
                    ? 'bg-blue-500 text-white'
                    : 'bg-gray-100 text-gray-600 hover:bg-gray-200'
                  }
                `}
              >
                {filter}
              </button>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Users List */}
      <div className="space-y-3">
        {filteredUsers.map((user) => (
          <Card key={user.id} className="shadow-sm border-0 rounded-2xl">
            <CardContent className="p-4">
              <div className="flex items-start justify-between">
                <div className="flex items-center flex-1">
                  <div className="w-14 h-14 rounded-full overflow-hidden bg-gray-200 mr-4">
                    <img
                      src={user.avatar}
                      alt={user.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center mb-1">
                      <h3 className="font-semibold text-gray-900 mr-2">{user.name}</h3>
                      <Badge 
                        className={`text-xs ${getRoleColor(user.role)}`}
                      >
                        {user.role}
                      </Badge>
                    </div>
                    
                    <div className="space-y-1">
                      <div className="flex items-center text-sm text-gray-600">
                        <Mail className="w-4 h-4 mr-2" />
                        {user.email}
                      </div>
                      <div className="flex items-center text-sm text-gray-600">
                        <Phone className="w-4 h-4 mr-2" />
                        {user.phone}
                      </div>
                    </div>
                    
                    <div className="flex items-center mt-2">
                      <Badge 
                        variant={user.status === 'active' ? 'default' : 'secondary'}
                        className={`text-xs mr-2 ${
                          user.status === 'active' 
                            ? 'bg-green-500 hover:bg-green-600' 
                            : 'bg-gray-400 hover:bg-gray-500'
                        }`}
                      >
                        {user.status === 'active' ? 'Activo' : 'Inactivo'}
                      </Badge>
                      <span className="text-xs text-gray-500">
                        Último acceso: {user.lastLogin}
                      </span>
                    </div>
                  </div>
                </div>

                <div className="flex flex-col space-y-2">
                  <Button
                    size="sm"
                    variant="outline"
                    className="rounded-lg"
                  >
                    <Edit className="w-4 h-4" />
                  </Button>
                  <Button
                    size="sm"
                    variant={user.status === 'active' ? 'destructive' : 'default'}
                    onClick={() => toggleUserStatus(user.id)}
                    className="rounded-lg"
                  >
                    {user.status === 'active' ? 'Desactivar' : 'Activar'}
                  </Button>
                </div>
              </div>

              {/* Permissions Preview */}
              <div className="mt-4 pt-4 border-t border-gray-100">
                <p className="text-sm text-gray-600 mb-2">Permisos:</p>
                <div className="flex flex-wrap gap-1">
                  {user.permissions.slice(0, 3).map((permission, index) => (
                    <Badge key={index} variant="outline" className="text-xs">
                      {permission.replace('_', ' ')}
                    </Badge>
                  ))}
                  {user.permissions.length > 3 && (
                    <Badge variant="outline" className="text-xs">
                      +{user.permissions.length - 3} más
                    </Badge>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {filteredUsers.length === 0 && (
        <div className="text-center py-12">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
            <User className="w-8 h-8 text-gray-400" />
          </div>
          <h3 className="text-lg font-medium text-gray-900 mb-2">
            No se encontraron usuarios
          </h3>
          <p className="text-gray-600">
            Intenta con otros términos de búsqueda o filtros
          </p>
        </div>
      )}

      {/* Create User Modal */}
      {showCreateModal && (
        <CreateUserModal
          onClose={() => setShowCreateModal(false)}
          onSuccess={handleCreateUser}
        />
      )}
    </div>
  );
}