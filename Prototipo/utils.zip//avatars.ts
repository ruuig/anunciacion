// Colección de avatares animados para el sistema
export const SCHOOL_LOGO = 'https://scontent.fgua6-1.fna.fbcdn.net/v/t39.30808-6/305744111_461409942667352_3087119728415018752_n.jpg?_nc_cat=109&ccb=1-7&_nc_sid=6ee11a&_nc_ohc=3b58j5VTSq8Q7kNvwF0vyjZ&_nc_oc=AdnBckzN5VCOXO1mw0McrHdLUHWBEvg2yl7RiKb9SryjWzYi5stD4goanXa9Rf-xxc8&_nc_zt=23&_nc_ht=scontent.fgua6-1.fna&_nc_gid=X49UiOP3wWnrDsSVe13SoA&oh=00_AffW_1IxcGR41t804C5kJTMRKKyYQt-9CctuUAdVjfqrog&oe=68E68BCA';

export const ANIMATED_AVATARS = {
  // Avatares para personal del colegio
  teachers: [
    'https://images.unsplash.com/photo-1750535135733-4ade39b4d487?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1750535135593-3a8e5def331d?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1744574005416-d558b1e44380?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1653671689368-13b828d04421?w=150&h=150&fit=crop&crop=center'
  ],
  
  // Avatares para estudiantes
  students: [
    'https://images.unsplash.com/photo-1588686201387-16edb00c86b1?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1561229474-1f22e022dfd4?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1740252117027-4275d3f84385?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1750535135733-4ade39b4d487?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1750535135593-3a8e5def331d?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1744574005416-d558b1e44380?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1653671689368-13b828d04421?w=150&h=150&fit=crop&crop=center',
    'https://images.unsplash.com/photo-1588686201387-16edb00c86b1?w=150&h=150&fit=crop&crop=center'
  ]
};

// Función para obtener un avatar aleatorio por tipo
export const getRandomAvatar = (type: 'teachers' | 'students' = 'students'): string => {
  const avatars = ANIMATED_AVATARS[type];
  return avatars[Math.floor(Math.random() * avatars.length)];
};

// Función para obtener un avatar específico por índice
export const getAvatarByIndex = (index: number, type: 'teachers' | 'students' = 'students'): string => {
  const avatars = ANIMATED_AVATARS[type];
  return avatars[index % avatars.length];
};