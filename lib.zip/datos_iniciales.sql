-- =====================================================
-- DATOS INICIALES - ROLES, USUARIOS, PERMISOS, NIVELES, MATERIAS
-- =====================================================

-- Roles
INSERT INTO roles (nombre, descripcion, nivel)
VALUES
('Administrador General', 'Acceso total a todo', 1),
('Docente', 'Acceso a clases y estudiantes', 2),
('Director/Secretaria', 'Acceso administrativo', 3),
('Padre', 'Acceso a hijos', 4)
ON CONFLICT (nombre) DO NOTHING;

-- Usuarios iniciales (usuario y contraseña estática)
INSERT INTO usuarios (nombre, username, telefono, rol_id, password_hash)
SELECT 'Administrador del Sistema', 'admin', '50212345678', r.id, crypt('admin123', gen_salt('bf'))
FROM roles r
WHERE r.nombre = 'Administrador General'
ON CONFLICT (username) DO UPDATE
SET password_hash = EXCLUDED.password_hash;

INSERT INTO usuarios (nombre, username, telefono, rol_id, password_hash)
SELECT 'Docente Ejemplo', 'docente1', '50223456789', r.id, crypt('docente123', gen_salt('bf'))
FROM roles r
WHERE r.nombre = 'Docente'
ON CONFLICT (username) DO UPDATE
SET password_hash = EXCLUDED.password_hash;

INSERT INTO usuarios (nombre, username, telefono, rol_id, password_hash)
SELECT 'Directora Ejemplo', 'directora1', '50234567890', r.id, crypt('directora123', gen_salt('bf'))
FROM roles r
WHERE r.nombre = 'Director/Secretaria'
ON CONFLICT (username) DO UPDATE
SET password_hash = EXCLUDED.password_hash;

INSERT INTO usuarios (nombre, username, telefono, rol_id, password_hash)
SELECT 'Padre Ejemplo', 'padre1', '50245678901', r.id, crypt('padre123', gen_salt('bf'))
FROM roles r
WHERE r.nombre = 'Padre'
ON CONFLICT (username) DO UPDATE
SET password_hash = EXCLUDED.password_hash;

-- Niveles educativos
INSERT INTO niveles_educativos (nombre, orden, color_hex)
VALUES
('Preprimaria', 1, '#EC4899'),
('Primaria', 2, '#3B82F6'),
('Secundaria', 3, '#10B981')
ON CONFLICT (nombre) DO NOTHING;

-- Materias básicas
INSERT INTO materias (nombre, codigo, descripcion)
VALUES
('Matemáticas', 'MAT', 'Matemáticas básicas y avanzadas'),
('Español', 'ESP', 'Lenguaje y comunicación'),
('Ciencias Naturales', 'CN', 'Biología, Física y Química'),
('Estudios Sociales', 'ES', 'Historia, Geografía y Civismo'),
('Inglés', 'ING', 'Idioma inglés'),
('Educación Física', 'EF', 'Actividad física y deporte'),
('Arte', 'ART', 'Expresión artística'),
('Computación', 'COMP', 'Tecnología e informática')
ON CONFLICT (nombre) DO NOTHING;

-- Conceptos de pago básicos
INSERT INTO conceptos_pago (nombre, descripcion, monto_por_defecto, tipo)
VALUES
('Colegiatura Mensual', 'Pago mensual por servicios educativos', 500.00, 'mensual'),
('Inscripción Anual', 'Pago de inscripción al inicio del año', 200.00, 'anual'),
('Materiales Escolares', 'Materiales y útiles escolares', 100.00, 'anual'),
('Eventos Especiales', 'Actividades extracurriculares', NULL, 'opcional'),
('Seguro Estudiantil', 'Seguro médico estudiantil', 50.00, 'anual')
ON CONFLICT (nombre) DO NOTHING;
