// Exportar todas las entidades del dominio
export 'educational_level.dart';
export 'grade.dart';
export 'grade_entry.dart';
export 'parent.dart';
export 'permission.dart';
export 'role.dart';
export 'section.dart';
export 'student.dart';
export 'student_parent.dart';
export 'subject.dart';
export 'user.dart';
