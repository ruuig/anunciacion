// Exportar todas las interfaces de repositorios
export 'base_repository.dart';
export 'grade_repository.dart';
export 'parent_repository.dart';
export 'role_repository.dart';
export 'section_repository.dart';
export 'student_grade_repository.dart';
export 'student_parent_repository.dart';
export 'student_repository.dart';
export 'subject_repository.dart';
export 'user_repository.dart';
