import 'dart:math';
import 'package:anunciacion/src/presentation/widgets/CustomCard.dart';
import 'package:anunciacion/src/presentation/widgets/bottomBar.dart';
import 'package:flutter/material.dart';

class HomeLuxuryPage extends StatefulWidget {
  const HomeLuxuryPage({super.key});

  @override
  State<HomeLuxuryPage> createState() => _HomeLuxuryPageState();
}

class _HomeLuxuryPageState extends State<HomeLuxuryPage> {
  int _tab = 0;

  // util para opacidad del banner
  double _collapsePercent(double t, double max) => (t / max).clamp(0.0, 1.0);

  @override
  Widget build(BuildContext context) {
    const blueDeep = Color(0xFF1D4ED8);
    const blueSoft = Color(0xFFDBEAFE);

    return Scaffold(
      backgroundColor: const Color(0xFFF5F7FB),
      body: NotificationListener<ScrollNotification>(
        onNotification: (_) => false,
        child: CustomScrollView(
          slivers: [
            // SliverAppBar con banner
            SliverAppBar(
              pinned: true,
              floating: false,
              expandedHeight: 170,
              backgroundColor: Colors.white,
              elevation: 0,
              scrolledUnderElevation: 0,
              automaticallyImplyLeading: false,
              flexibleSpace: LayoutBuilder(
                builder: (context, c) {
                  final t = c.constrainHeight(); //  kToolbarHeight..expanded
                  final percent = 1 -
                      _collapsePercent(
                        max(0, t - kToolbarHeight),
                        170 - kToolbarHeight,
                      ); // 0 = expandido, 1 = colapsado

                  return Stack(
                    fit: StackFit.expand,
                    children: [
                      // ======= Banner Colegio (se desvanece al colapsar) =======
                      Opacity(
                        opacity: (1 - percent),
                        child: Container(
                          padding: const EdgeInsets.fromLTRB(20, 16, 20, 16),
                          decoration: const BoxDecoration(
                            gradient: LinearGradient(
                              colors: [Color(0xFFEFF5FF), Color(0xFFFFFFFF)],
                              begin: Alignment.topCenter,
                              end: Alignment.bottomCenter,
                            ),
                          ),
                          child: Row(
                            children: [
                              // Logo grande
                              Container(
                                width: 64,
                                height: 64,
                                child: Container(
                                  width: 64,
                                  height: 64,
                                  decoration: BoxDecoration(
                                    shape: BoxShape.circle,
                                    border:
                                        Border.all(color: blueSoft, width: 5),
                                    color: Colors.white,
                                    boxShadow: [
                                      BoxShadow(
                                        color: Colors.black.withOpacity(0.06),
                                        blurRadius: 12,
                                        offset: const Offset(0, 4),
                                      )
                                    ],
                                  ),
                                  clipBehavior: Clip.antiAlias,
                                  child: Image.asset(
                                    'assets/logoanunciacion.png',
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) {
                                      print('Error loading image: $error');
                                      return const Icon(
                                        Icons.school_rounded,
                                        size: 32,
                                        color: Colors.grey,
                                      );
                                    },
                                  ),
                                ),
                              ),
                              const SizedBox(width: 14),
                              const Expanded(
                                child: Column(
                                  mainAxisAlignment: MainAxisAlignment.center,
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      'Colegio Parroquial',
                                      style: TextStyle(
                                        fontSize: 13,
                                        color: Color(0xFF64748B),
                                        fontWeight: FontWeight.w600,
                                      ),
                                    ),
                                    SizedBox(height: 4),
                                    Text(
                                      'Nuestra Señora de la Anunciación',
                                      maxLines: 2,
                                      overflow: TextOverflow.ellipsis,
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.w900,
                                        color: Color(0xFF0F172A),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                            ],
                          ),
                        ),
                      ),

                      // ======= Barra compacta (perfil + nombre) =======
                      Align(
                        alignment: Alignment.bottomCenter,
                        child: Container(
                          height: kToolbarHeight,
                          padding: const EdgeInsets.symmetric(horizontal: 16),
                          child: Row(
                            children: [
                              // nombre solo cuando colapsa
                              AnimatedOpacity(
                                opacity: percent.clamp(0.0, 1.0),
                                duration: const Duration(milliseconds: 200),
                                child: const Text(
                                  'María González',
                                  style: TextStyle(
                                    fontWeight: FontWeight.w800,
                                    fontSize: 18,
                                    color: Color(0xFF0F172A),
                                  ),
                                ),
                              ),
                              const Spacer(),
                              CircleAvatar(
                                radius: 18,
                                backgroundImage: const NetworkImage(
                                  'https://ui-avatars.com/api/?name=Maria+G&background=E5E7EB&color=111827',
                                ),
                                backgroundColor: Colors.grey.shade200,
                              ),
                            ],
                          ),
                        ),
                      ),
                    ],
                  );
                },
              ),
            ),

            // Perfil resumido (bajo el banner cuando está expandido)
            SliverToBoxAdapter(
              child: Container(
                color: Colors.white,
                padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
                child: const Row(
                  children: [
                    CircleAvatar(
                      radius: 22,
                      backgroundImage: NetworkImage(
                        'https://ui-avatars.com/api/?name=Maria+G&background=E5E7EB&color=111827',
                      ),
                    ),
                    SizedBox(width: 12),
                    Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text('María González',
                            style: TextStyle(
                                fontWeight: FontWeight.w800, fontSize: 16)),
                        SizedBox(height: 3),
                        Text('Grado asignado: 3° Primaria',
                            style: TextStyle(
                                color: Color(0xFF64748B), fontSize: 13)),
                      ],
                    ),
                  ],
                ),
              ),
            ),

            // ======= Cards =======
            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
              sliver: SliverList.list(
                children: const [
                  _SectionTitle('Accesos rápidos'),
                ],
              ),
            ),

            SliverPadding(
              padding: const EdgeInsets.fromLTRB(16, 10, 16, 16),
              sliver: SliverGrid(
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2, // ← dos por fila
                  crossAxisSpacing: 12,
                  mainAxisSpacing: 12,
                  childAspectRatio: 0.82, // ajusta altura; 0.8–0.9 luce bien
                ),
                delegate: SliverChildListDelegate([
                  CustomCard(
                    imageUrl: 'assets/notas.png',
                    title: 'Calificaciones',
                    description: 'Consulta y registra notas por curso',
                    onTap: () {},
                  ),
                  CustomCard(
                    imageUrl: 'assets/descarga.png',
                    title: 'Pagos',
                    description: 'Cuotas, estados y comprobantes',
                    onTap: () {},
                  ),
                  CustomCard(
                    imageUrl: 'assets/reportes.png',
                    title: 'Reportes',
                    description: 'Promedios y boletas por grado',
                    onTap: () {},
                  ),
                  CustomCard(
                    imageUrl: 'assets/estudiantes.png',
                    title: 'Estudiantes',
                    description: 'Perfiles, asistencia y familiares',
                    onTap: () {},
                  ),
                  CustomCard(
                    imageUrl: 'assets/asistencia.png',
                    title: 'Calendario',
                    description: 'Eventos y recordatorios',
                    onTap: () {},
                  ),
                  CustomCard(
                    imageUrl: 'assets/configuracion.png',
                    title: 'Configuración',
                    description: 'Preferencias y usuarios',
                    onTap: () {},
                  ),
                ]),
              ),
            ),
          ],
        ),
      ),

      // ======= Bottom bar elegante =======
      bottomNavigationBar: BottomBar(
        index: _tab,
        onChanged: (i) => setState(() => _tab = i),
      ),
    );
  }
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);
  final String text;

  @override
  Widget build(BuildContext context) {
    return Text(
      text,
      style: const TextStyle(
        fontWeight: FontWeight.w800,
        fontSize: 18,
        color: Color(0xFF0F172A),
      ),
    );
  }
}
