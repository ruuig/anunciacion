import 'dart:math' as math;
import 'package:flutter/material.dart';

/// Sliver Large Navbar estilo iOS (grande -> compacto)
/// - Inspirado en Apple Music / App Store
/// - Minimalista, limpio, organizado
/// - Muestra: título grande, subtítulo, logo; al colapsar queda compacto
///
/// Uso: coloca este sliver al inicio de tu CustomScrollView.
class CustomAppBAr extends SliverPersistentHeaderDelegate {
  CustomAppBAr({
    required this.title,
    this.subtitle,
    this.logo,
    this.avatarUrl,
    this.onAvatarTap,
    this.actions,
    this.background = Colors.white,
    this.accent = const Color(0xFF60A5FA), // celestito del colegio
    this.expandedHeight = 200,
  });

  final String title;
  final String? subtitle;
  final Widget? logo; // e.g. Image.asset('assets/logo.png', width: 56)
  final String? avatarUrl; // url del avatar (compacto)
  final VoidCallback? onAvatarTap;
  final List<Widget>? actions; // iconos compactos opcionales
  final Color background;
  final Color accent;
  final double expandedHeight;

  @override
  double get maxExtent => expandedHeight;
  @override
  double get minExtent => kToolbarHeight + 6;
  @override
  bool shouldRebuild(covariant CustomAppBAr oldDelegate) =>
      oldDelegate.title != title ||
      oldDelegate.subtitle != subtitle ||
      oldDelegate.logo != logo ||
      oldDelegate.avatarUrl != avatarUrl ||
      oldDelegate.background != background ||
      oldDelegate.expandedHeight != expandedHeight;

  @override
  Widget build(
      BuildContext context, double shrinkOffset, bool overlapsContent) {
    final t = (shrinkOffset / (maxExtent - minExtent)).clamp(0.0, 1.0);
    // Interpolaciones
    final bigTitleSize = lerp(30, 18, t);
    final bigPaddingTop = lerp(18, 0, t);
    final bigPaddingBottom = lerp(14, 0, t);
    final bigOpacity = (1 - t); // se desvanece al colapsar
    final compactOpacity = t; // aparece al colapsar

    return Container(
      color: background,
      child: Stack(
        fit: StackFit.expand,
        children: [
          // ===== Sección expandida (gran título + subtítulo + logo) =====
          Opacity(
            opacity: bigOpacity,
            child: Padding(
              padding: EdgeInsets.fromLTRB(
                  16,
                  bigPaddingTop + MediaQuery.of(context).padding.top,
                  16,
                  bigPaddingBottom),
              child: Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  // Texto grande
                  Expanded(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Text(
                          title,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: TextStyle(
                            fontSize: bigTitleSize,
                            fontWeight: FontWeight.w900,
                            color: const Color(0xFF0F172A),
                            height: 1.05,
                          ),
                        ),
                        if (subtitle != null) ...[
                          const SizedBox(height: 6),
                          Text(
                            subtitle!,
                            maxLines: 2,
                            overflow: TextOverflow.ellipsis,
                            style: TextStyle(
                              fontSize: 14,
                              color: Colors.grey.shade600,
                              height: 1.2,
                            ),
                          ),
                        ],
                      ],
                    ),
                  ),
                  const SizedBox(width: 12),
                  // Logo del colegio en una “medalla”
                  if (logo != null)
                    Container(
                      width: 60,
                      height: 60,
                      decoration: BoxDecoration(
                        shape: BoxShape.circle,
                        border: Border.all(
                            color: const Color(0xFFDBEAFE), width: 5),
                        color: Colors.white,
                        boxShadow: [
                          BoxShadow(
                            color: Colors.black.withOpacity(0.06),
                            blurRadius: 12,
                            offset: const Offset(0, 4),
                          )
                        ],
                      ),
                      alignment: Alignment.center,
                      child: ClipOval(child: logo),
                    ),
                ],
              ),
            ),
          ),

          // ===== Barra compacta (aparece al colapsar) =====
          Align(
            alignment: Alignment.bottomCenter,
            child: Opacity(
              opacity: compactOpacity,
              child: Container(
                height: kToolbarHeight + 6,
                padding: EdgeInsets.only(
                  top: MediaQuery.of(context).padding.top,
                  left: 12,
                  right: 6,
                ),
                child: Row(
                  children: [
                    const SizedBox(width: 4),
                    // Título compacto
                    Expanded(
                      child: Text(
                        title,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          fontSize: 18,
                          fontWeight: FontWeight.w800,
                          color: Color(0xFF0F172A),
                        ),
                      ),
                    ),
                    // Acciones opcionales
                    if (actions != null) ...actions!,
                    const SizedBox(width: 6),
                    // Avatar
                    GestureDetector(
                      onTap: onAvatarTap,
                      child: CircleAvatar(
                        radius: 18,
                        backgroundImage: (avatarUrl != null)
                            ? NetworkImage(avatarUrl!)
                            : null,
                        backgroundColor: Colors.grey.shade200,
                        child: avatarUrl == null
                            ? Icon(Icons.person_rounded,
                                color: Colors.grey.shade600)
                            : null,
                      ),
                    ),
                    const SizedBox(width: 8),
                  ],
                ),
              ),
            ),
          ),

          // ===== Separador inferior sutil =====
          Align(
            alignment: Alignment.bottomCenter,
            child: Container(
              height: 1,
              margin: EdgeInsets.only(top: minExtent - 1),
              color: Colors.black.withOpacity(0.04 * t),
            ),
          ),
        ],
      ),
    );
  }

  double lerp(double a, double b, double t) => a + (b - a) * t;
}
